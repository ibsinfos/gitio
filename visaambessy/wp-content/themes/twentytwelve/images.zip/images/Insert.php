<?php
/*
* Template Name: Insert Page 
*/

$wish_to_migrate = array();
$Condidate=$_POST['Condidate'];
$telephone=$_POST['telephone'];
$Email=$_POST['Email'];
$age=$_POST['age'];
$Nationality=$_POST['Nationality'];
$wish_to_migrate=$_POST['wish_to_migrate'];
$current_live=$_POST['current_live'];
$planning=$_POST['planning'];
$Type_of_Visa=$_POST['Type_of_Visa'];
$job_title=$_POST['job_title'];
$Qualifications=$_POST['Qualifications'];
$experience=$_POST['experience'];
$file=$_FILES['file']['name'];
$file2=$_FILES['file']['tmp_name'];
print_r($wish_to_migrate);
$comments=$_POST['comments'];



mysql_connect("localhost","infowiz_migrate","oyi)ISDSJbJU")or die(mysql_error());
mysql_select_db("infowiz_migrate");




mysql_query("insert into visaform values('','$Condidate','$telephone','$Email','$age','$Nationality','$wish_to_migrate','$current_live',
'$planning','$Type_of_Visa','$job_title','$Qualifications','$experience','$file','$comments')")or die(mysql_error());  


echo"done";
?>



