<?php
/*
 * Template Name : Visa Page
 */

get_header(); ?>

<div class="row">
  <div class="container">
    <div class="col-md-12">
      <div class="col-md-5 set2">
        <div class="sidebar">
          <h3>Visa Assessment</h3>
          <div class="frrasse_bg">
            <div class="no1"></div>
            <div class="fr_txt"> &nbsp;&nbsp;Where do you live? </div>
            <div class="drp_dwn_pnl">
              <select class="drpDwnlst">
                <option selected="selected" label="Select your country of residence" value="">Select your country of residence</option>
                <option value="3">Afghanistan</option>
                <option value="4">Albania</option>
                <option value="5">Algeria</option>
                <option value="6">American Samoa</option>
                <option value="7">Andorra</option>
                <option value="8">Angola</option>
                <option value="9">Anguilla</option>
                <option value="10">Antarctica</option>
                <option value="11">Antigua and/or Barbuda</option>
                <option value="12">Argentina</option>
                <option value="13">Armenia</option>
                <option value="14">Aruba</option>
                <option value="15">Australia</option>
                <option value="16">Austria</option>
                <option value="17">Azerbaijan</option>
                <option value="18">Bahamas</option>
                <option value="19">Bahrain</option>
                <option value="20">Bangladesh</option>
                <option value="21">Barbados</option>
                <option value="22">Belarus</option>
                <option value="23">Belgium</option>
                <option value="24">Belize</option>
                <option value="25">Benin</option>
                <option value="26">Bermuda</option>
                <option value="27">Bhutan</option>
                <option value="28">Bolivia</option>
                <option value="29">Bosnia and Herzegovina</option>
                <option value="30">Botswana</option>
                <option value="31">Bouvet Island</option>
                <option value="32">Brazil</option>
                <option value="33">British lndian Ocean Territory</option>
                <option value="34">Brunei Darussalam</option>
                <option value="35">Bulgaria</option>
                <option value="36">Burkina Faso</option>
                <option value="37">Burundi</option>
                <option value="38">Cambodia</option>
                <option value="39">Cameroon</option>
                <option value="2">Canada</option>
                <option value="40">Cape Verde</option>
                <option value="41">Cayman Islands</option>
                <option value="42">Central African Republic</option>
                <option value="43">Chad</option>
                <option value="44">Chile</option>
                <option value="45">China</option>
                <option value="46">Christmas Island</option>
                <option value="47">Cocos (Keeling) Islands</option>
                <option value="48">Colombia</option>
                <option value="49">Comoros</option>
                <option value="50">Congo</option>
                <option value="51">Cook Islands</option>
                <option value="52">Costa Rica</option>
                <option value="53">Croatia (Hrvatska)</option>
                <option value="54">Cuba</option>
                <option value="55">Cyprus</option>
                <option value="56">Czech Republic</option>
                <option value="57">Denmark</option>
                <option value="58">Djibouti</option>
                <option value="59">Dominica</option>
                <option value="60">Dominican Republic</option>
                <option value="61">East Timor</option>
                <option value="62">Ecudaor</option>
                <option value="63">Egypt</option>
                <option value="64">El Salvador</option>
                <option value="65">Equatorial Guinea</option>
                <option value="66">Eritrea</option>
                <option value="67">Estonia</option>
                <option value="68">Ethiopia</option>
                <option value="69">Falkland Islands (Malvinas)</option>
                <option value="70">Faroe Islands</option>
                <option value="71">Fiji</option>
                <option value="72">Finland</option>
                <option value="73">France</option>
                <option value="74">France, Metropolitan</option>
                <option value="75">French Guiana</option>
                <option value="76">French Polynesia</option>
                <option value="77">French Southern Territories</option>
                <option value="78">Gabon</option>
                <option value="79">Gambia</option>
                <option value="80">Georgia</option>
                <option value="81">Germany</option>
                <option value="82">Ghana</option>
                <option value="83">Gibraltar</option>
                <option value="84">Greece</option>
                <option value="85">Greenland</option>
                <option value="86">Grenada</option>
                <option value="87">Guadeloupe</option>
                <option value="88">Guam</option>
                <option value="89">Guatemala</option>
                <option value="90">Guinea</option>
                <option value="91">Guinea-Bissau</option>
                <option value="92">Guyana</option>
                <option value="93">Haiti</option>
                <option value="94">Heard and Mc Donald Islands</option>
                <option value="95">Honduras</option>
                <option value="96">Hong Kong</option>
                <option value="97">Hungary</option>
                <option value="98">Iceland</option>
                <option value="99">India</option>
                <option value="100">Indonesia</option>
                <option value="101">Iran (Islamic Republic of)</option>
                <option value="102">Iraq</option>
                <option value="103">Ireland</option>
                <option value="104">Israel</option>
                <option value="105">Italy</option>
                <option value="106">Ivory Coast</option>
                <option value="107">Jamaica</option>
                <option value="108">Japan</option>
                <option value="109">Jordan</option>
                <option value="110">Kazakhstan</option>
                <option value="111">Kenya</option>
                <option value="112">Kiribati</option>
                <option value="113">Korea, Democratic People's Republic of</option>
                <option value="114">Korea, Republic of</option>
                <option value="115">Kuwait</option>
                <option value="116">Kyrgyzstan</option>
                <option value="117">Lao People's Democratic Republic</option>
                <option value="118">Latvia</option>
                <option value="119">Lebanon</option>
                <option value="120">Lesotho</option>
                <option value="121">Liberia</option>
                <option value="122">Libyan Arab Jamahiriya</option>
                <option value="123">Liechtenstein</option>
                <option value="124">Lithuania</option>
                <option value="125">Luxembourg</option>
                <option value="126">Macau</option>
                <option value="127">Macedonia</option>
                <option value="128">Madagascar</option>
                <option value="129">Malawi</option>
                <option value="130">Malaysia</option>
                <option value="131">Maldives</option>
                <option value="132">Mali</option>
                <option value="133">Malta</option>
                <option value="134">Marshall Islands</option>
                <option value="135">Martinique</option>
                <option value="136">Mauritania</option>
                <option value="137">Mauritius</option>
                <option value="138">Mayotte</option>
                <option value="139">Mexico</option>
                <option value="140">Micronesia, Federated States of</option>
                <option value="141">Moldova, Republic of</option>
                <option value="142">Monaco</option>
                <option value="143">Mongolia</option>
                <option value="144">Montserrat</option>
                <option value="145">Morocco</option>
                <option value="146">Mozambique</option>
                <option value="147">Myanmar</option>
                <option value="148">Namibia</option>
                <option value="149">Nauru</option>
                <option value="150">Nepal</option>
                <option value="151">Netherlands</option>
                <option value="152">Netherlands Antilles</option>
                <option value="153">New Caledonia</option>
                <option value="154">New Zealand</option>
                <option value="155">Nicaragua</option>
                <option value="156">Niger</option>
                <option value="157">Nigeria</option>
                <option value="158">Niue</option>
                <option value="159">Norfork Island</option>
                <option value="160">Northern Mariana Islands</option>
                <option value="161">Norway</option>
                <option value="162">Oman</option>
                <option value="163">Pakistan</option>
                <option value="164">Palau</option>
                <option value="165">Panama</option>
                <option value="166">Papua New Guinea</option>
                <option value="167">Paraguay</option>
                <option value="168">Peru</option>
                <option value="169">Philippines</option>
                <option value="170">Pitcairn</option>
                <option value="171">Poland</option>
                <option value="172">Portugal</option>
                <option value="173">Puerto Rico</option>
                <option value="174">Qatar</option>
                <option value="175">Reunion</option>
                <option value="176">Romania</option>
                <option value="177">Russian Federation</option>
                <option value="178">Rwanda</option>
                <option value="179">Saint Kitts and Nevis</option>
                <option value="180">Saint Lucia</option>
                <option value="181">Saint Vincent and the Grenadines</option>
                <option value="182">Samoa</option>
                <option value="183">San Marino</option>
                <option value="184">Sao Tome and Principe</option>
                <option value="185">Saudi Arabia</option>
                <option value="240">Schengen</option>
                <option value="186">Senegal</option>
                <option value="187">Seychelles</option>
                <option value="188">Sierra Leone</option>
                <option value="189">Singapore</option>
                <option value="190">Slovakia</option>
                <option value="191">Slovenia</option>
                <option value="192">Solomon Islands</option>
                <option value="193">Somalia</option>
                <option value="194">South Africa</option>
                <option value="195">South Georgia South Sandwich Islands</option>
                <option value="196">Spain</option>
                <option value="197">Sri Lanka</option>
                <option value="198">St. Helena</option>
                <option value="199">St. Pierre and Miquelon</option>
                <option value="200">Sudan</option>
                <option value="201">Suriname</option>
                <option value="202">Svalbarn and Jan Mayen Islands</option>
                <option value="203">Swaziland</option>
                <option value="204">Sweden</option>
                <option value="205">Switzerland</option>
                <option value="206">Syrian Arab Republic</option>
                <option value="207">Taiwan</option>
                <option value="208">Tajikistan</option>
                <option value="209">Tanzania, United Republic of</option>
                <option value="210">Thailand</option>
                <option value="211">Togo</option>
                <option value="212">Tokelau</option>
                <option value="213">Tonga</option>
                <option value="214">Trinidad and Tobago</option>
                <option value="215">Tunisia</option>
                <option value="216">Turkey</option>
                <option value="217">Turkmenistan</option>
                <option value="218">Turks and Caicos Islands</option>
                <option value="219">Tuvalu</option>
                <option value="220">Uganda</option>
                <option value="221">Ukraine</option>
                <option value="222">United Arab Emirates</option>
                <option value="223">United Kingdom</option>
                <option value="1">United States</option>
                <option value="224">United States minor outlying islands</option>
                <option value="225">Uruguay</option>
                <option value="226">Uzbekistan</option>
                <option value="227">Vanuatu</option>
                <option value="228">Vatican City State</option>
                <option value="229">Venezuela</option>
                <option value="230">Vietnam</option>
                <option value="232">Virgin Islands (U.S.)</option>
                <option value="231">Virigan Islands (British)</option>
                <option value="233">Wallis and Futuna Islands</option>
                <option value="234">Western Sahara</option>
                <option value="235">Yemen</option>
                <option value="236">Yugoslavia</option>
                <option value="237">Zaire</option>
                <option value="238">Zambia</option>
                <option value="239">Zimbabwe</option>
              </select>
            </div>
          </div>
          <div class="frrasse_bg1">
            <div class="no2"></div>
            <div class="fr_txt"> &nbsp;&nbsp;  Where do you want to go? </div>
            <div class="drp_dwn_pnl">
              <select class="drpDwnlst">
                <option selected="selected" label="Select your country of choice" value="">Select your country of choice</option>
                <option label="---------------------------------" value=" ">---------------------------------</option>
                <option value="15">Australia</option>
                <option value="2">Canada</option>
                <option value="57">Denmark</option>
                <option value="223">United Kingdom</option>
              </select>
            </div>
          </div>
          <div class="button-back">
            <button class="btn btn-primary go" type="submit"> &nbsp;<span style="margin:-22px 0 0 20px;">Go</span> </button>
          </div>
        </div>
      </div>
      <div class="col-md-7 set2">
        <div class="banner"> <img src="<?php echo get_template_directory_uri(); ?>/images/banner1.png" /> </div>
      </div>
      </div>
    <!--Row of search bar and banner-->
    <!--div class="row"-->
     <div class="col-md-12">
        <div class="msg-box">
          <p>
          		As one of the most successful immigration consultancies in the world, Emigration-Expert has helped individuals, families, and 			 				corporate clients with their visa applications for many years. Our consultants are legally trained and keep up to date on the 		 				ever-changing immigration rules for the United Kingdom, Canada, Australia, and Denmark.Emigration-Expert is considered the expert 
                of experts and whether youâ€™re a student or a high net worth investor, we aim to make your immigration dreams come true. We 
                provide you with unrivaled service throughout the visa process. This is why most of our customers say they would recommend us.
          </p>
        </div>
    </div>
    <div class="col-md-12" style="width:101%; float: left; margin-top: -7px;">
          <div class="col-sm-6 col-md-6 set2"> 
            <img alt="Work Visa" src="<?php echo get_template_directory_uri(); ?>/images/panel-work.jpg" class="bg">
          <div>
          <h2>
          	<img src="<?php echo get_template_directory_uri(); ?>/images/austrailia.png"> 
            <span class="country-color">Australia </span> Visas</h2>
          	<span class="desc"> 
            	Australia Work Permits
          		Australia Business Visas
          		Australia Immigration 
            </span> 
            <img src="<?php echo get_template_directory_uri(); ?>/images/panel-button-action.png" class="action"> 
            </div>
      </div>
      <div class="col-sm-6 col-md-6 set2"> <img alt="Work Visa" src="<?php echo get_template_directory_uri(); ?>/images/panel-travel.jpg" class="bg">
        <div>
          <h2><img src="<?php echo get_template_directory_uri(); ?>/images/canada.png"><span class="country-color">Canada </span>Visas</h2>
          <span class="desc"> Canada Work Permits
          Canada Immigration
          Canada Business Visas </span> <img src="<?php echo get_template_directory_uri(); ?>/images/panel-button-action.png" class="action"> </div>
      </div>
    </div>
    <div class="col-md-12" style="width:101%; float: left; margin-top: -10px;">
      <div class="col-sm-6 col-md-6 set2"> <img alt="Work Visa" src="<?php echo get_template_directory_uri(); ?>/images/panel-working-holiday.jpg" class="bg">
        <div>
          <h2><img src="<?php echo get_template_directory_uri(); ?>/images/denmark.png"><span class="country-color">Denmark</span> Visas</h2>
          <span class="desc"> Denmark Work Permits
          Move to the Denmark
          Denmark Business Visas </span> <img src="<?php echo get_template_directory_uri(); ?>/images/panel-button-action.png" class="action"> </div>
      </div>
      <div class="col-sm-6 col-md-6 set2"> <img alt="Work Visa" src="<?php echo get_template_directory_uri(); ?>/images/panel-family.jpg" class="bg">
        <div>
          <h2><img src="<?php echo get_template_directory_uri(); ?>/images/uk.png"><span class="country-color">UK </span> Visas</h2>
          <span class="desc"> UK Work Permits
          UK Tier Visas
          UK Business Visas </span> <img src="<?php echo get_template_directory_uri(); ?>/images/panel-button-action.png" class="action"> </div>
      </div>
    </div>
 	<!--div class="col-md-12" style="border: 1px solid #CCCCCC;border-radius: 10px;margin: 10px 0 0 1.5%;width: 98%;">
    	<img src="<?php //echo get_template_directory_uri();?>/images/BHF Logo.png" class="logoset"/>
    </div--> 
 </div> 
</div> 
<?php get_footer(); ?>
