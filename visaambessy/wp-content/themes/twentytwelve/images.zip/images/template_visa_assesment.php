<?php
/*
  Template Name: Free Visa Assesment
 */
get_header();
?>

<div class="row">
    <div class="container">
        <div class="row">
            <div class="col-md-12 stVikas">
                <div class="row">
                    <h1>FREE VISA ASSESMENT FORM</h1>
                    <h4>3 QUICK and EASY STEPS</h4>
                    <img class="step1" width="997" height="54" alt="visa-assesment-step1" src="http://migrate-me.com/wp-content/themes/wedovisas/images/step-1.jpg">
					<img class="step2" src="http://migrate-me.com/wp-content/themes/wedovisas/images/step-2.jpg" width="997" height="54" alt="visa-assesment-step1"/> 
                    <img class="step3" src="http://migrate-me.com/wp-content/themes/wedovisas/images/step-3.jpg" width="997" height="54" alt="visa-assesment-step1"/>
                    <div class="col-lg-4">
                        <form class="one_third" id="my_awesome_form1" role="form" method="post">
                            <div class="assesmentFormHeight">
                                <h3>About You</h3>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <label for="inputName">Name</label>
                                            <input type="text" id="Condidate" placeholder="Name" name="Condidate" class="form-control">
                                        </div>
                                    </div>
                                    <span id="Condidate1" class="error_validate"></span> </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <label for="inputTelephone">Telephone</label>
                                            <input type="text" id="telephone" name="telephone" placeholder="Telephone" class="form-control">
                                        </div>
                                    </div>
                                    <span id="telephone1" class="error_validate"></span> </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <label for="inputEmail">Email</label>
                                            <input type="text" id="txtEmail1" name="Email" placeholder="Email" class="form-control">
                                        </div>
                                    </div>
                                    <span id="email1" class="error_validate"></span> </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <label for="inputAge">Age</label>
                                            <select id="age" name="age" class="form-control">
                                                <option value="">Select</option>
                                                <option value="18">18</option>
                                                <option value="19">19</option>
                                                <option value="20">20</option>
                                                <option value="21">21</option>
                                                <option value="22">22</option>
                                                <option value="23">23</option>
                                                <option value="24">24</option>
                                                <option value="25">25</option>
                                                <option value="26">26</option>
                                                <option value="27">27</option>
                                                <option value="28">28</option>
                                                <option value="29">29</option>
                                                <option value="30">30</option>
                                                <option value="31">31</option>
                                                <option value="32">32</option>
                                                <option value="33">33</option>
                                                <option value="34">34</option>
                                                <option value="35">35</option>
                                                <option value="36">36</option>
                                                <option value="37">37</option>
                                                <option value="38">38</option>
                                                <option value="39">39</option>
                                                <option value="40">40</option>
                                                <option value="41">41</option>
                                                <option value="42">42</option>
                                                <option value="43">43</option>
                                                <option value="44">44</option>
                                                <option value="45">45</option>
                                                <option value="46">46</option>
                                                <option value="47">47</option>
                                                <option value="48">48</option>
                                                <option value="49">49</option>
                                                <option value="50">50</option>
                                                <option value="51">51</option>
                                                <option value="52">52</option>
                                                <option value="53">53</option>
                                                <option value="54">54</option>
                                                <option value="55">55</option>
                                                <option value="56">56</option>
                                                <option value="57">57</option>
                                                <option value="58">58</option>
                                                <option value="59">59</option>
                                                <option value="60">60</option>
                                                <option value="61">61</option>
                                                <option value="62">62</option>
                                                <option value="63">63</option>
                                                <option value="64">64</option>
                                                <option value="65">65</option>
                                                <option value="66">66</option>
                                                <option value="67">67</option>
                                                <option value="68">68</option>
                                                <option value="69">69</option>
                                                <option value="70">70</option>
                                                <option value="71">71</option>
                                                <option value="72">72</option>
                                                <option value="73">73</option>
                                                <option value="74">74</option>
                                                <option value="75">75</option>
                                                <option value="76">76</option>
                                                <option value="77">77</option>
                                                <option value="78">78</option>
                                                <option value="79">79</option>
                                                <option value="80">80</option>
                                                <option value="81">81</option>
                                                <option value="82">82</option>
                                                <option value="83">83</option>
                                                <option value="84">84</option>
                                                <option value="85">85</option>
                                                <option value="86">86</option>
                                                <option value="87">87</option>
                                                <option value="88">88</option>
                                                <option value="89">89</option>
                                                <option value="90">90</option>
                                                <option value="91">91</option>
                                                <option value="92">92</option>
                                                <option value="93">93</option>
                                                <option value="94">94</option>
                                                <option value="95">95</option>
                                                <option value="96">96</option>
                                                <option value="97">97</option>
                                                <option value="98">98</option>
                                                <option value="99">99</option>
                                                <option value="100">100</option>
                                            </select>
                                        </div>
                                    </div>
                                    <span id="age1" class="error_validate"></span> </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <label for="inputNationality">Nationality</label>
                                            <input type="text" id="Nationality" name="Nationality" placeholder="Nationality" class="form-control">
                                        </div>
                                    </div>
                                    <span id="Nationality1" class="error_validate"></span>
                                </div>

                                <!--changes made for adding captcha-->
                                <div class="comment-form-captcha form-group">
                                    <img width="72" height="24" alt="captcha" src="http://migrate-me.com/wp-content/plugins/really-simple-captcha/tmp/532726917.png">
                                    <br>
                                    <!--<label for="captcha_code">Please enter above characters</label>-->
                                    <input type="text" placeholder="Please enter above characters" size="4" name="comment_captcha_code" class="form-control" id="comment_captcha_code">
                                    <span id="captcha-validate" class="error_validate"></span>
                                    <input type="hidden" value="532726917" name="comment_captcha_prefix" id="comment_captcha_prefix">
                                </div>
                                <!--#changes made for adding captcha-->		 
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <button onclick="return validate1();" class="btn btn-primary" type="button"> Proceed to Step 2 </button>
                                    </div>
                                </div>
                            </div>
                            <!--<button type="button" class="btn btn-primary" onclick="return validate1();"> SUBMIT &amp; CONTINUE </button>-->


                            <div id="progress"> <span id="percent">Step1</span>
                                <div id="bar"></div>
                            </div>
                        </form>
                    </div>

                    <div class="col-lg-4">
                        <form class="one_third" id="my_awesome_form2" method="post" role="form" style="opacity: 0.3;">
                            <div class="assesmentFormHeight">
                                <!-- Step1 -->
                                <h3>About your destination</h3>
                                <div class="form-group">
                                    <label for="checkbox1">Where do you wish to go</label>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" id="Australia" name="wish_to_migrate[]" value="Australia" disabled="">
                                            Australia </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" id="Canada" name="wish_to_migrate[]" value="Canada" disabled="">
                                            Canada </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" id="Denmark" name="wish_to_migrate[]" value="Denmark" disabled="">
                                            Denmark </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" id="USA" name="wish_to_migrate[]" value="USA" disabled="">
                                            USA </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" id="Undecided" name="wish_to_migrate[]" value="Undecided" disabled="">
                                            Undecided </label>
                                    </div>
                                    <span id="wish_to_migrate1" class="error_validate"></span> </div>
                                <div class="form-group">
                                    <label for="radio1">Where do you currently live</label>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" value="UK" id="current_live1" name="current_live" disabled="">
                                            UK </label>
                                    </div>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" value="Outside the UK" id="current_live2" name="current_live" disabled="">
                                            Outside the UK </label>
                                    </div>
                                    <span id="current_live1_1" class="error_validate"></span> </div>
                                <div class="form-group">
                                    <label for="radio2">When are you planning to go</label>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" value="ASAP" id="plan1" name="planning" disabled="">
                                            ASAP </label>
                                    </div>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" value="3-6 months" id="plan2" name="planning" disabled="">
                                            3-6 months </label>
                                    </div>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" value="6-9 months" id="plan3" name="planning" disabled="">
                                            6-9 months </label>
                                    </div>
                                    <span id="planning123" class="error_validate"></span> </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <label for="Type of Visa">Type of Visa required</label>
                                            <select id="Type_of_Visa" name="Type_of_Visa" class="form-control" disabled="">
                                                <option value="">Select</option>
                                                <option value="Work Visa">Work Visa</option>
                                                <option value="Business Visa">Business Visa</option>
                                                <option value="Family Visa">Family Visa</option>
                                                <option value="Student Visa">Student Visa</option>
                                                <option value="Tourist Visa">Tourist Visa</option>
                                                <option value="Permanent Residency">Permanent Residency</option>
                                                <option value="Other / Not sure">Other / Not sure</option>
                                            </select>
                                        </div>
                                    </div>
                                    <span id="Type_of_Visa1" class="error_validate"></span> </div>			  
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <button onclick="return validate2();" class="btn btn-primary" type="button" disabled=""> Proceed to Step 3 </button>
                                    </div>
                                </div>
                            </div>
                            <!--<button type="button" class="btn btn-primary" onclick="return validate2();" > SUBMIT &amp; CONTINUE </button>-->


                            <div id="progress1"> <span id="percent1">Step2</span>
                                <div id="bar1"></div>
                            </div>
                        </form>
                    </div>

                    <div class="col-lg-4">
                        <form action="http://migrate-me.com/free-visa-assessment/" class="one_third_last" id="my_awesome_form3" enctype="multipart/form-data" role="form" method="post" style="opacity: 0.3;">
                            <div class="assesmentFormHeight">
                                <!-- Step3 -->
                                <h3>About your Profession</h3>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <label for="inputOccupation">Your Occupation</label>
                                            <input type="text" id="job_title" name="job_title" placeholder="Your Occupation" class="form-control" disabled="">
                                        </div>
                                    </div>
                                    <span id="job_title1" class="error_validate"></span> </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <label for="inputQualification">Your highest level of qualification</label>
                                            <select id="Qualifications" name="Qualifications" class="form-control" disabled="">
                                                <option value="">Select</option>
                                                <option value="PhD">PhD</option>
                                                <option value="Masters">Masters</option>
                                                <option value="Bachelor">Bachelor</option>
                                                <option value="Diploma">Diploma</option>
                                                <option value="Certificate">Certificate</option>
                                            </select>
                                        </div>
                                    </div>
                                    <span id="Qualifications1" class="error_validate"></span> </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <label for="inputExp">Number of years of work experience</label>
                                            <select id="experience" name="experience" class="form-control" disabled="">
                                                <option value="">Select</option>
                                                <option value="Less than a year">Less than a year</option>
                                                <option value="1 year">1 year</option>
                                                <option value="2 years">2 years</option>
                                                <option value="3 years">3 years</option>
                                                <option value="4 years+">4 years+</option>
                                            </select>
                                        </div>
                                    </div>
                                    <span id="experience1" class="error_validate"></span> </div>
                                <!-- <div class="form-group">
                                      <div class="row">
                                        <div class="col-lg-3">
                                              <label for="inputExp">English language ability</label>
                                              <select class="form-control" name="english" id="english">
                                                <option value="">Select</option>
                                                <option value="English is my first language">English is my first language</option>
                                                <option value="Advanced">Advanced</option>
                                                <option value="Intermediate">Intermediate</option>
                                                <option value="Basic">Basic</option>
                                              </select>
                                        </div>
                                      </div>
                                      <span  class="error_validate" id="english1"></span> </div> -->
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <label for="uploadCV">Upload your resume (<span class="red">optional</span>)</label>
                                            <input type="file" accept=".doc,.docx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/pdf,.pdf,text/plain,application/rtf" id="uploadCV" name="file" class="form-control-cv" disabled="">					 
                                        </div>
                                    </div>				
                                    <span id="uploadCV1" class="error_validate"><span class="gray">Please upload a word, txt, rtf or pdf file only.</span></span> </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <label for="comments">Comments (<span class="red">If any</span>)</label>
                                            <textarea id="comments" name="comments" class="form-control-cv" disabled=""></textarea>
                                           <!-- <input type="file" class="form-control" name="uploadCV" id="uploadCV"> -->
                                        </div>
                                    </div>
                                    <span id="comments1" class="error_validate"></span> </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <label>&nbsp;
                                            </label>
                                        </div>
                                    </div>
                                </div>			  
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <button onclick="return validate3();" class="btn btn-primary" type="button" disabled=""> SUBMIT </button>
                                    </div>
                                </div>
                            </div>

                            <style>
                                #progress2 {
                                    width: 50%;   
                                    border: 1px solid black;
                                    position: relative;
                                    padding: 3px;
                                    margin-top:20px;
                                }

                                #percent2 {
                                    position: absolute;   
                                    left: 50%;
                                    color:#0000FF;
                                    font-weight:bold;
                                }

                                #bar2 {
                                    height: 20px;
                                    background-color: #00ff00;
                                    width: 100%;
                                }
                                .Search_box #search_form #s{
                                    padding:22px; 
                                }
                                #search_form{
                                    padding-right:7px;
                                }

                                .form-control-cv:focus {
                                    border: medium none #66AFE9;
                                    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(102, 175, 233, 0.6);
                                    outline: 0 none;
                                }

                                .form-control-cv {
                                    background: none repeat scroll 0 0 #FFFFFF;
                                    border: 1px solid #CCCCCC;
                                    border-radius: 4px;
                                    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset;
                                    outline: 0 none;
                                    padding: 6px 12px;
                                    transition: border-color 0.15s ease-in-out 0s, box-shadow 0.15s ease-in-out 0s;
                                    width: 100%;
                                }
                                
                                .btn-primary{color:#fff;background-color:#428bca;
                                            border-color:#357ebd}
                                .btn-primary:hover,.btn-primary:focus,.btn-primary:active,.btn-primary.active,.open .dropdown-toggle.btn-primary{color:#fff;background-color:#3276b1;
                                            border-color:#285e8e}
                            </style>
                            <div id="progress2"> <span id="percent2">Step3</span>
                                <div id="bar2"></div>
                            </div>
                        </form>
                    </div>
                    <p style="padding-top:30px; float: left;"> "Please note we will not rent or sell your personal information to anyone. The information provided here will only be used by Migrate Me for assessment purpose"</p>
                </div>  
            </div>
        </div>
    </div>
</div>


<script type="text/javascript">
     $(document).ready(function() {
    $("#my_awesome_form2").css({
      "opacity": "0.3"
    });
    $("#my_awesome_form3").css({
      "opacity": "0.3"
    });
    $("#my_awesome_form2 :input").prop("disabled", true);

    $("#my_awesome_form3 :input").prop("disabled", true);
  });
  function validate1()
  {
    var cond = document.getElementById("Condidate").value;

    if (cond == '')
    {
      document.getElementById('Condidate1').innerHTML = "Please Enter Your Name";

      document.getElementById("Condidate").focus();

      return false;
    }

    else if (!isNaN(cond))
    {

      document.getElementById('Condidate1').innerHTML = "Please enter a valid name";

      document.getElementById("Condidate").focus();

      return false;
    }

    else
    {
      document.getElementById("Condidate1").innerHTML = "";
    }

    var tel = document.getElementById("telephone").value;
    if (tel == '')
    {
      document.getElementById('telephone1').innerHTML = "Please Enter Your Phone No.";

      document.getElementById("telephone").focus();

      return false;
    }
    else if (isNaN(tel))
    {

      document.getElementById('telephone1').innerHTML = "Please enter a valid number";

      document.getElementById("telephone").focus();

      return false;
    }
    else
    {
      document.getElementById("telephone1").innerHTML = "";
    }

    email = document.getElementById("txtEmail1").value;


    if (email == '') {


      document.getElementById('email1').innerHTML = "Please Enter Email ID";

      document.getElementById("txtEmail1").focus();

      return false;
    } else {
      document.getElementById("email1").innerHTML = "";
    }

    if (email != '')
    {

      if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email))) {
        document.getElementById('email1').innerHTML = "Please Enter Right Email_Id";

        document.getElementById("txtEmail1").focus();
        return false;
      }

    }

    else {
      document.getElementById("email1").innerHTML = "";
    }


    if (document.getElementById("age").value == '')
    {
      document.getElementById('age1').innerHTML = "Please Select Your Age";

      document.getElementById("age").focus();

      return false;
    }
    else
    {
      document.getElementById("age1").innerHTML = "";
    }


    if (document.getElementById("Nationality").value == '')
    {
      document.getElementById('Nationality1').innerHTML = "Please Enter Your Country";

      document.getElementById("Nationality").focus();

      return false;
    }
    else
    {
      document.getElementById("Nationality1").innerHTML = "";
    }

    abc();



  }


  function abc()
  {


    var form1 = $('#my_awesome_form1');
    var datasting1 = form1.serialize();

    $('#centerLoader').show();
    $.ajax({
      type: "POST",
      url: form1.attr('action'),
      data: datasting1,
      success: function(response) {
        if (response != "false") {
		  document.getElementById('captcha-validate').innerHTML = "";
		  $("#my_awesome_form2").prop({
			disabled: true
		  });
		  $("#my_awesome_form3").prop({
			disabled: true
		  });
		  $("#my_awesome_form1").css({
			"opacity": "0.3"
		  });
		  $("#my_awesome_form2").css({
			"opacity": "1"
		  });
		  $("#my_awesome_form3").css({
			"opacity": "0.3"
		  });
		  $("#my_awesome_form1 :input").prop("disabled", true);
		  $("#my_awesome_form2 :input").removeAttr('disabled');
		  $("#my_awesome_form3 :input").prop("disabled", true);
		  $('.step2').css('display', 'block');
		  $('.step1').css('display', 'none');
		  $('#centerLoader').hide();
		  
		  
          
        }
        else {
          $('#centerLoader').hide();
          document.getElementById('captcha-validate').innerHTML = "Please enter correct characters.";
          document.getElementById("comment_captcha_code").focus();
          //alert("Please enter correct character in captcha validation");
        }
      },
	  error: function(){
					alert("Unexpected error occured. Please wait a while and try again.");
	  }
    });


  }


  function validate2()
  {

    if ((document.getElementById("Australia").checked == false) && (document.getElementById("Canada").checked == false) && (document.getElementById("Denmark").checked == false) && (document.getElementById("USA").checked == false) && (document.getElementById("Undecided").checked == false))
    {
      document.getElementById('wish_to_migrate1').innerHTML = "Please Choose One Option";
      return false;
    }
    else
    {
      document.getElementById("wish_to_migrate1").innerHTML = "";

    }

    if ((document.getElementById("current_live1").checked == false) && (document.getElementById("current_live2").checked == false))
    {
      document.getElementById('current_live1_1').innerHTML = "Please Choose One Option";
      return false;
    }
    else
    {
      document.getElementById("current_live1_1").innerHTML = "";

    }


    if ((document.getElementById("plan1").checked == false) && (document.getElementById("plan2").checked == false) && (document.getElementById("plan3").checked == false))
    {
      document.getElementById('planning123').innerHTML = "Please Choose One Option";
      return false;
    }
    else
    {
      document.getElementById("planning123").innerHTML = "";

    }

    if (document.getElementById("Type_of_Visa").value == '')
    {
      document.getElementById('Type_of_Visa1').innerHTML = "Please Select Type of Visa";

      document.getElementById("Type_of_Visa").focus();

      return false;
    }
    else
    {
      document.getElementById("Type_of_Visa1").innerHTML = "";
    }




    abc1();


  }


  function abc1()
  {



    var form = $('#my_awesome_form2');
    var datasting = form.serialize();

    $('#centerLoader').show();
    $.ajax({
      type: "POST",
      url: form.attr('action'),
      data: datasting,
      success: function(response) {
		$('.step1').css('display', 'none');
        $('.step2').css('display', 'none');
        $('.step3').css('display', 'block');

        $("#my_awesome_form1").css({
          "opacity": "0.3"
        });
        $("#my_awesome_form2").css({
          "opacity": "0.3"
        });
        $("#my_awesome_form3").css({
          "opacity": "1"
        });
        $("#my_awesome_form1 :input").prop("disabled", true);
        $("#my_awesome_form2 :input").prop("disabled", true);
        $("#my_awesome_form3 :input").removeAttr('disabled');

        //   $('#my_awesome_form1').hide();
        //   $('#my_awesome_form3').show();
        //   $('#my_awesome_form2').hide();
        $('#centerLoader').hide();


      }
    });


  }

  function validate3()
  {
    var occupation = document.getElementById("job_title").value;
    if (occupation == '')
    {
      document.getElementById('job_title1').innerHTML = "Please Enter Your Occupation";

      document.getElementById("job_title").focus();

      return false;
    }
    else if (!isNaN(occupation))
    {

      document.getElementById('job_title1').innerHTML = "Please enter occupation";

      document.getElementById("job_title").focus();

      return false;
    }
    else
    {
      document.getElementById("job_title1").innerHTML = "";
    }

    if (document.getElementById("Qualifications").value == '')
    {
      document.getElementById('Qualifications1').innerHTML = "Please Select Your Qualifications";

      document.getElementById("Qualifications").focus();

      return false;
    }
    else
    {
      document.getElementById("Qualifications1").innerHTML = "";
    }


    if (document.getElementById("experience").value == '')
    {
      document.getElementById('experience1').innerHTML = "Please Select Your Experience";

      document.getElementById("experience").focus();

      return false;
    }
    else
    {
      document.getElementById("experience1").innerHTML = "";
    }




    /* if (document.getElementById("english").value == '')
    {
      document.getElementById('english1').innerHTML = "Please Select Your English language ability";

      document.getElementById("english").focus();

      return false;
    }
    else
    {
      document.getElementById("english1").innerHTML = "";
    } */ 
	
	if ((document.getElementById("uploadCV").value != '')){
		var strFileExt	= document.getElementById("uploadCV").value;
		strFileExt		= strFileExt.split('.');
		var strFileExt	= strFileExt[strFileExt.length -1];
			
		if((strFileExt == 'pdf') || (strFileExt == 'doc') || (strFileExt == 'odt') || (strFileExt == 'docx')){
			document.getElementById('uploadCV1').innerHTML = "";
		}else{
			var answer = confirm('The file you have selected is not a valid file. Click on "Yes" if you wish to continue without a Resume. Else click on "Cancel" to upload a valid file ?');
            if (answer){
              
            }
            else{
              document.getElementById('uploadCV1').innerHTML = "Please upload a word, txt, rtf or pdf file only.";
              document.getElementById("uploadCV").val('');
              return false;
			}
		}
		
		
	}
	

    abc2();

  }

  $(document).ready(function(){
    var file = document.getElementById('uploadCV');
    file.onchange = function(e){
        var ext = this.value.match(/\.([^\.]+)$/)[1];
        switch(ext)
        {
            case 'pdf':
            case 'doc':
            case 'docx':
            case 'rtf':
            case 'txt':
              document.getElementById('uploadCV1').innerHTML = "";
              break;
            default:
              document.getElementById('uploadCV1').innerHTML = "Please upload a word, txt, rtf or pdf file only.";
              break;
        }
    };
  });
  
  $('#centerLoader').hide().ajaxStart(function(){
	  $(this).show();
  }).ajaxStop(function() {
	  $(this).hide();
  });
  
  
  function abc2(){
	$('#centerLoader').show();
	$('.step1').css('display', 'none');
	$('.step2').css('display', 'none');
	$('.step3').css('display', 'block');
	setTimeout(function(){
			abc2_final();
		},100);
  }
  
  function abc2_final()
  {
    
    var form2 = $('#my_awesome_form3');
    var datasting2 = new FormData(jQuery('#my_awesome_form3')[0]);;
	
	$.ajax({
		type: "POST",
		url: form2.attr('action'),
		data: datasting2,
		dataType: 'text',
		async: false,
		cache: false,
		contentType: false,
		processData: false,	  
		success: function(response) {
			$('#centerLoader').hide();
			$("#my_awesome_form1").css({
			  "opacity": "0.3"
			});
			$("#my_awesome_form2").css({
			  "opacity": "0.3"
			});
			$("#my_awesome_form3").css({
			  "opacity": "0.3"
			});
	
			$("#my_awesome_form1 :input").prop("disabled", true);
			$("#my_awesome_form2 :input").prop("disabled", true);
			$("#my_awesome_form3 :input").prop('disabled', true);
  
			window.location.href = 'http://global-migrate.infowiz.in/thank-you/';
			return false;
		},
		error: function(){
			window.location.href = 'http://global-migrate.infowiz.in/thank-you/';
		}
     });

    return false;

  } 
</script>

<?php //get_sidebar(); ?>
<?php get_footer(); ?>