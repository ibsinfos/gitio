<?PHP
require_once("./include/membersite_config.php");

if(isset($_POST['submitted']))
{
   if($fgmembersite->RegisterUser())
   {
        $fgmembersite->RedirectToURL("thank-you.html");
   }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
    <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
    <title>Contact us</title>
    <link rel="STYLESHEET" type="text/css" href="style/form.css" />
    <script type='text/javascript' src='scripts/gen_validatorv31.js'></script>
    <link rel="STYLESHEET" type="text/css" href="style/pwdwidget.css" />
    <script src="scripts/pwdwidget.js" type="text/javascript"></script>      
</head>
<body>

<!-- Form Code Start -->
<div id='fg_membersite'>
<form id='register' action='<?php echo $fgmembersite->GetSelfScript(); ?>' method='post' accept-charset='UTF-8'>
<fieldset >
<legend>Registratie</legend>

<input type='hidden' name='submitted' id='submitted' value='1'/>

<div class='short_explanation'>* vereiste velden</div>
<input type='text'  class='spmhidip' name='<?php echo $fgmembersite->GetSpamTrapInputName(); ?>' />

<div><span class='error'><?php echo $fgmembersite->GetErrorMessage(); ?></span></div>
<div class='container'>
    <label for='name' >Volledige naam*: </label><br/>
    <input type='text' name='name' id='name' value='<?php echo $fgmembersite->SafeDisplay('name') ?>' maxlength="50" /><br/>
    <span id='register_name_errorloc' class='error'></span>
</div>
<div class='container'>
    <label for='email' >Email Adres*:</label><br/>
    <input type='text' name='email' id='email' value='<?php echo $fgmembersite->SafeDisplay('email') ?>' maxlength="50" /><br/>
    <span id='register_email_errorloc' class='error'></span>
</div>
<div class='container'>
    <label for='username' >Gebruikersnaam*:</label><br/>
    <input type='text' name='username' id='username' value='<?php echo $fgmembersite->SafeDisplay('username') ?>' maxlength="50" /><br/>
    <span id='register_username_errorloc' class='error'></span>
</div>
<div class='container' style='height:160px;'>
    <label for='password' >Wachtwoord*:</label><br/>
	<input type="password" name="password" /></label>
	<div id='register_password_errorloc' class='error' style='clear:both'></div>

    <label for='confirmpassword' >Bevestig Wachtwoord*:</label><br/>
	<input type="password" name="confirmpassword" /></label>
	<div id='register_confirmpassword_errorloc' class='error' style='clear:both'></div>
<div class='short_explanation'><i>Let op: gebruik nooit hetzelfde wachtwoord als op andere websites.</i></div>	
</div>

<div class='container'>
    <input type='submit' name='Submit' value='Verstuur' />
</div>

</fieldset>
</form>
<!-- client-side Form Validations:
Uses the excellent form validation script from JavaScript-coder.com-->

<script type='text/javascript'>
// <![CDATA[

    
    var frmvalidator  = new Validator("register");
    frmvalidator.EnableOnPageErrorDisplay();
    frmvalidator.EnableMsgsTogether();
    frmvalidator.addValidation("name","req","Vul uw naam in.");

    frmvalidator.addValidation("email","req","Vul uw email adres in.");

    frmvalidator.addValidation("email","email","Vul een correct email adres in.");

    frmvalidator.addValidation("username","req","Vul een gebruikersnaam in.");
    
    frmvalidator.addValidation("password","req","Vul een wachtwoord in.");
	frmvalidator.addValidation("confirmpassword","req","Vul een wachtwoord in.");

// ]]>
</script>


</body>
</html>