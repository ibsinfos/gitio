# NHP Theme Options V1.0.6 #

NHP Theme Options Framework has been replaced by the Fluent Framework which is out now! Please direct all issues / requests to The Fluent Framework:

http://no-half-pixels.github.io/Fluent-Framework/
