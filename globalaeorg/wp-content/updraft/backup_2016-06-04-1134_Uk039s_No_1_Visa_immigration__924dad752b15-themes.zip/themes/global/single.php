<?php
/**
 * The template for displaying all single posts
 *
 * @package WordPress
 * @subpackage Twenty_Thirteen
 * @since Twenty Thirteen 1.0
 */

get_header(); ?>
ssadsdsdasdsadsadsa
	
<?php get_sidebar(); ?>
<?php get_footer(); ?>