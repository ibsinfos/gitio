<?php
_deprecated_file( __FILE__, '4.0', 'Tribe__Cache.php' );

class Tribe__Events__Cache extends Tribe__Cache {}
