<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Main' );


	class TribeEvents extends Tribe__Events__Main {

	}