<?php

	if ( ! defined( 'ABSPATH' ) ) exit;

	global $prdctfltr_global;

	$prdctfltr_global['woo_template'] = 'result_count';

	include_once( 'product-filter.php' );

?>