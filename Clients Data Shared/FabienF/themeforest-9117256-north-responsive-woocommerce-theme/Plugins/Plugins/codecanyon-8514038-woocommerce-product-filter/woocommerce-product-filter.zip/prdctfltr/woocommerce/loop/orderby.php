<?php

	if ( ! defined( 'ABSPATH' ) ) exit;

	global $prdctfltr_global;

	$prdctfltr_global['woo_template'] = 'order_by';

	include_once( 'product-filter.php' );

?>