<?php

/**
 * Admin settings page footer view
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

