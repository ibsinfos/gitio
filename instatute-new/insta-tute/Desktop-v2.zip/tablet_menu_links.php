<div id="dmSlideRightNavLeft" class="menuClosed"> 
<div class="fixedPart"> 
    <a name="nav" id="navAnchor"></a>
<div id="hiddenNavPlaceHolder" class="hiddenNavPlaceHolder navPlaceHolder dmDisplay_None dmn dmLayoutNav"> <ul class="dmNav dmNavCustom dmn dmMobile_navNoIcons dmTablet_navNoIcons default" id="dmNav" dmnavfullyann="true" shape_class="default" exp_align="right" exp_nps="true" exp_npt="false" exp_hmi="false" exp_hma="false" exp_btn_mnutitle="Menu" btmtitle="Back to menu" mmtitle="Main Menu" hwa="false" dmmoreicon="icon-angle-down" dmlessicon="icon-angle-up" dmhomeicon="icon-home" design_classes="dmMobile_navNoIcons dmTablet_navNoIcons" style="display: block"> <li class="p_list_item dmUDNavigationItem_00_li dmHideFromNav-mobile dmHideFromNav-tablet dmHideFromNav-desktop" id="dm_navGroup00_item" dmnav_annotate="title_changed;" nav_hidden-mobile="true" nav_hidden-tablet="true" nav_hidden-desktop="true"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/home?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_00 dm_navGroup00a" id="dm_navGroup00a" icon-name="icon-home" raw_url="/site/5b24469b/home"> <div class="navIconBg" id="1959256709"> <div class="navIcon navItemIcon" id="dm_navGroup00icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup00div">Home</div> 
 <div class="navArrowBg" id="1232673487"> <div class="navArrow" id="1523839124"></div> 
 <div class="navArrowBottom" id="1817920035"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup00s"></ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_010101408542_li dmNavShownItem" id="dm_navGroup010101408542_item" dmnav_annotate="inserted;"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/home?preview=true&amp;insitepreview=true&amp;dm_device=desktop#AboutUs" class="dmUDNavigationItem_010101408542 dm_navGroup010101408542a" icon-name="icon-star" id="dm_navGroup010101408542a" raw_url="/site/5b24469b/home#AboutUs"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101408542icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101408542div">ABOUT US</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup010101408542s"></ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_010101296766_li dmHideFromNav-desktop dmHideFromNav-tablet dmHideFromNav-mobile" id="dm_navGroup010101296766_item" dmnav_annotate="inserted;" nav_hidden-desktop="true" nav_hidden-tablet="true" nav_hidden-mobile="true"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/home?preview=true&amp;insitepreview=true&amp;dm_device=desktop#Testimonials" class="dmUDNavigationItem_010101296766 dm_navGroup010101296766a" icon-name="icon-star" id="dm_navGroup010101296766a" raw_url="/site/5b24469b/home#Testimonials"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101296766icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101296766div">TESTIMONIALS</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup010101296766s"></ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_010101395268_li dmNavShownItem" id="dm_navGroup010101395268_item" dmnav_annotate="inserted;"> 
     <a href="#" class="dmUDNavigationItem_010101395268 dm_navGroup010101395268a" icon-name="icon-star" id="dm_navGroup010101395268a" raw_url="/site/5b24469b/home#SpecialOffer"> 
         <div class="navIconBg"> 
             <div class="navIcon navItemIcon" id="dm_navGroup010101395268icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101395268div">SPECIAL OFFER</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup010101395268s"></ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_010101854108_li dmNavShownItem" id="dm_navGroup010101854108_item" dmnav_annotate="inserted;"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/home?preview=true&amp;insitepreview=true&amp;dm_device=desktop#ContactUs" class="dmUDNavigationItem_010101854108 dm_navGroup010101854108a" icon-name="icon-star" id="dm_navGroup010101854108a" raw_url="/site/5b24469b/home#ContactUs"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101854108icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101854108div">CONTACT US</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup010101854108s"></ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_010101409697_li dmNavShownItem" id="dm_navGroup010101409697_item" dmnav_annotate="inserted;"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/for-tutors1?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101409697 dm_navGroup010101409697a" icon-name="dm-icon-w_email" id="dm_navGroup010101409697a" raw_url="/site/5b24469b/for-tutors1"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101409697icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101409697div">TUTORS</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="dmNav" id="dm_navGroup010101409697s"> <li class="p_list_item dmUDNavigationItem_010101372970_li" id="dm_navGroup010101372970_item" dmnav_annotate="inserted;"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/faqs?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101372970 dm_navGroup010101372970a" icon-name="dm-icon-page-list" id="dm_navGroup010101372970a" raw_url="/site/5b24469b/faqs"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101372970icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101372970div">FAQs: TUTORS</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup010101372970s"></ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_010101429671_li" id="dm_navGroup010101429671_item" dmnav_annotate="inserted;"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/sign-up-as-a-tutor?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101429671 dm_navGroup010101429671a" icon-name="dm-icon-w_email" id="dm_navGroup010101429671a" raw_url="/site/5b24469b/sign-up-as-a-tutor"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101429671icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101429671div">SIGN UP AS A TUTOR</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup010101429671s"></ul> 
</li> 
</ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_010101269917_li dmNavShownItem" id="dm_navGroup010101269917_item" dmnav_annotate="inserted;"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/for-students-or-parents1?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101269917 dm_navGroup010101269917a" icon-name="icon-star" id="dm_navGroup010101269917a" raw_url="/site/5b24469b/for-students-or-parents1"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101269917icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101269917div">FOR STUDENTS OR PARENTS</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="dmNav" id="dm_navGroup010101269917s"> <li class="p_list_item dmUDNavigationItem_010101562672_li" id="dm_navGroup010101562672_item" dmnav_annotate="inserted;"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/copy-of-faqs?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101562672 dm_navGroup010101562672a" icon-name="icon-star" id="dm_navGroup010101562672a" raw_url="/site/5b24469b/copy-of-faqs"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101562672icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101562672div">FAQs: STUDENTS/PARENTS</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup010101562672s"></ul> 
</li> 
</ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_010101631964_li dmHideFromNav-desktop dmHideFromNav-tablet dmHideFromNav-mobile" id="dm_navGroup010101631964_item" dmnav_annotate="inserted;" nav_hidden-desktop="true" nav_hidden-tablet="true" nav_hidden-mobile="true"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/disclaimer1?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101631964 dm_navGroup010101631964a" icon-name="dm-icon-blank" id="dm_navGroup010101631964a" raw_url="/site/5b24469b/disclaimer1"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101631964icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101631964div">DISCLAIMER</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup010101631964s"></ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_010101437899_li dmNavShownItem" id="dm_navGroup010101437899_item" dmnav_annotate="inserted;"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/privacy-policy?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101437899 dm_navGroup010101437899a" icon-name="icon-star" id="dm_navGroup010101437899a" raw_url="/site/5b24469b/privacy-policy"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101437899icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101437899div">PRIVACY POLICY</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup010101437899s"></ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_010101676483_li dmNavShownItem" id="dm_navGroup010101676483_item" dmnav_annotate="inserted;"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/newpage?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101676483 dm_navGroup010101676483a" icon-name="icon-star" id="dm_navGroup010101676483a" raw_url="/site/5b24469b/newpage"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101676483icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101676483div">TERMS &amp; CONDITIONS</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup010101676483s"></ul> 
</li> 
</ul> 
 <ul class="dmNav dmNavCustom dmn"> <li class="p_list_item dmUDNavigationItem_dmMore_li dmHideFromNav" id="dmMore"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/home?preview=true&amp;insitepreview=true&amp;dm_device=desktop#" class="dmUDNavigationItem_dmMore dmMorea" icon-name="icon-angle-down" id="dmMorea"> <div class="navIconBg"> <div class="navIcon hasFontIcon fontIconName" id="dmMoreicon"></div> 
</div> 
 <div class="navText" id="dmMorediv">MORE</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dmMores"></ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_dmLess_li dmHideFromNav" id="dmLess"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/home?preview=true&amp;insitepreview=true&amp;dm_device=desktop#" class="dmUDNavigationItem_dmLess dmLessa" icon-name="icon-angle-up" id="dmLessa"> <div class="navIconBg"> <div class="navIcon hasFontIcon fontIconName" id="dmLessicon"></div> 
</div> 
 <div class="navText" id="dmLessdiv">LESS</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dmLesss"></ul> 
</li> 
</ul> 
</div> 
<ul id="leftSidebar" class="dmMobile_navNoIcons dmTablet_navNoIcons dmNavWrapper dmn dmLayoutNav"> <li class="${li_class} leftSidebarBtnHidden dmHideFromNav navListLi" id="leftSidebarBtnHidden"> <a data-href="${href}" dm_dont_rewrite_url="true" class="${a_class}" target="${a_target}" icon-name="${font_icon}" data-target-page-alias=""> <span class="navItemIconBg"> <span class="navItemIcon ${font_icon}"></span> 
</span> 
 <span class="navItemText">${text}</span> 
 <span class="navItemArrowBg"> <span class="navItemArrow"></span> 
</span> 
</a> 
</li> 
<li class="navListLi" id="dm_navGroup010101408542_item"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/home?preview=true&amp;insitepreview=true&amp;dm_device=tablet#AboutUs" class="dmUDNavigationItem_010101408542" icon-name="icon-star" data-target-page-alias="" raw_url="/site/5b24469b/home#AboutUs"> <span class="navItemIconBg"> <span class="navItemIcon  hasFontIcon icon-star "></span> 
</span> 
 <span class="navItemText">ABOUT US</span> 
 <span class="navItemArrowBg"> <span class="navItemArrow"></span> 
</span> 
</a> 
</li><li class="navListLi" id="dm_navGroup010101395268_item"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/home?preview=true&amp;insitepreview=true&amp;dm_device=tablet#SpecialOffer" class="dmUDNavigationItem_010101395268" icon-name="icon-star" data-target-page-alias="" raw_url="/site/5b24469b/home#SpecialOffer"> <span class="navItemIconBg"> <span class="navItemIcon  hasFontIcon icon-star "></span> 
</span> 
 <span class="navItemText">SPECIAL OFFER</span> 
 <span class="navItemArrowBg"> <span class="navItemArrow"></span> 
</span> 
</a> 
</li><li class="navListLi" id="dm_navGroup010101854108_item"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/home?preview=true&amp;insitepreview=true&amp;dm_device=tablet#ContactUs" class="dmUDNavigationItem_010101854108" icon-name="icon-star" data-target-page-alias="" raw_url="/site/5b24469b/home#ContactUs"> <span class="navItemIconBg"> <span class="navItemIcon  hasFontIcon icon-star "></span> 
</span> 
 <span class="navItemText">CONTACT US</span> 
 <span class="navItemArrowBg"> <span class="navItemArrow"></span> 
</span> 
</a> 
</li><li class="navListLi    hasdmSub" id="dm_navGroup010101409697_item"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/for-tutors1?preview=true&amp;insitepreview=true&amp;dm_device=tablet" class="dmUDNavigationItem_010101409697" icon-name="dm-icon-w_email" data-target-page-alias="" raw_url="/site/5b24469b/for-tutors1"> <span class="navItemIconBg"> <span class="navItemIcon  hasFontIcon dm-icon-w_email "></span> 
</span> 
 <span class="navItemText">TUTORS</span> 
 <span class="navItemArrowBg"> <span class="navItemArrow"></span> 
</span> 
</a> 
 <ul class="innerUl"><li class="navListLi   dmSub" id="dm_navGroup010101372970_item"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/faqs?preview=true&amp;insitepreview=true&amp;dm_device=tablet" class="dmUDNavigationItem_010101372970" icon-name="dm-icon-page-list" data-target-page-alias="" raw_url="/site/5b24469b/faqs"> <span class="navItemIconBg"> <span class="navItemIcon  hasFontIcon dm-icon-page-list "></span> 
</span> 
 <span class="navItemText">FAQs: TUTORS</span> 
 <span class="navItemArrowBg"> <span class="navItemArrow"></span> 
</span> 
</a> 
</li><li class="navListLi   dmSub" id="dm_navGroup010101429671_item"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/sign-up-as-a-tutor?preview=true&amp;insitepreview=true&amp;dm_device=tablet" class="dmUDNavigationItem_010101429671" icon-name="dm-icon-w_email" data-target-page-alias="" raw_url="/site/5b24469b/sign-up-as-a-tutor"> <span class="navItemIconBg"> <span class="navItemIcon  hasFontIcon dm-icon-w_email "></span> 
</span> 
 <span class="navItemText">SIGN UP AS A TUTOR</span> 
 <span class="navItemArrowBg"> <span class="navItemArrow"></span> 
</span> 
</a> 
</li></ul> 
</li><li class="navListLi    hasdmSub" id="dm_navGroup010101269917_item"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/for-students-or-parents1?preview=true&amp;insitepreview=true&amp;dm_device=tablet" class="dmUDNavigationItem_010101269917" icon-name="icon-star" data-target-page-alias="" raw_url="/site/5b24469b/for-students-or-parents1"> <span class="navItemIconBg"> <span class="navItemIcon  hasFontIcon icon-star "></span> 
</span> 
 <span class="navItemText">FOR STUDENTS OR PARENTS</span> 
 <span class="navItemArrowBg"> <span class="navItemArrow"></span> 
</span> 
</a> 
 <ul class="innerUl"><li class="navListLi   dmSub" id="dm_navGroup010101562672_item"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/copy-of-faqs?preview=true&amp;insitepreview=true&amp;dm_device=tablet" class="dmUDNavigationItem_010101562672" icon-name="icon-star" data-target-page-alias="" raw_url="/site/5b24469b/copy-of-faqs"> <span class="navItemIconBg"> <span class="navItemIcon  hasFontIcon icon-star "></span> 
</span> 
 <span class="navItemText">FAQs: STUDENTS/PARENTS</span> 
 <span class="navItemArrowBg"> <span class="navItemArrow"></span> 
</span> 
</a> 
</li></ul> 
</li><li class="navListLi" id="dm_navGroup010101437899_item"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/privacy-policy?preview=true&amp;insitepreview=true&amp;dm_device=tablet" class="dmUDNavigationItem_010101437899" icon-name="icon-star" data-target-page-alias="" raw_url="/site/5b24469b/privacy-policy"> <span class="navItemIconBg"> <span class="navItemIcon  hasFontIcon icon-star "></span> 
</span> 
 <span class="navItemText">PRIVACY POLICY</span> 
 <span class="navItemArrowBg"> <span class="navItemArrow"></span> 
</span> 
</a> 
</li><li class="navListLi" id="dm_navGroup010101676483_item"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/newpage?preview=true&amp;insitepreview=true&amp;dm_device=tablet" class="dmUDNavigationItem_010101676483" icon-name="icon-star" data-target-page-alias="" raw_url="/site/5b24469b/newpage"> <span class="navItemIconBg"> <span class="navItemIcon  hasFontIcon icon-star "></span> 
</span> 
 <span class="navItemText">TERMS &amp; CONDITIONS</span> 
 <span class="navItemArrowBg"> <span class="navItemArrow"></span> 
</span> 
</a> 
</li></ul>
</div>
    </div>
<div style="clear:both"></div>