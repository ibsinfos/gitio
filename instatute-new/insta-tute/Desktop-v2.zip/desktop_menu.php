<!-- desktop menu by gaurav -->
<div class="dmHeaderContainer fHeader d-header-wrapper gaurav-desktop-menu"> <div id="hcontainer" class="u_hcontainer dmHeader p_hfcontainer" freeheader="true"> <div dm:templateorder="85" class="dmHeaderResp dmHeaderStack noSwitch" id="1709005236"> <div class="u_1082398226 dmRespRow fullBleedChanged fullBleedMode" style="text-align: center;" id="1082398226"> <div class="dmRespColsWrapper u_1133881732" id="1133881732"> <div class="u_1349400908 dmRespCol small-12 large-2 medium-2" id="1349400908"> <div class="u_1449079828 imageWidget" editablewidget="true" data-widget-type="image" id="1449079828"> <a href="#" id="1704066974" class="u_1704066974" dm_dont_rewrite_url="false" file="false" raw_url="/site/5b24469b/home#Home"><img src="42b29b43-abdb-46bb-9ddc-8b35013f6004-large-944x250.png" id="1552245209" class="u_1552245209" dm_changed="true" onerror="handleImageLoadError(this)"></a> 
</div> 
</div> 
 <div class="u_1241224165 dmRespCol small-12 large-8 medium-8" id="1241224165"> <span id="1547204211"></span> 
 <div class="u_1507089131 default dmLinksMenu desktopNavWrapper" id="1507089131" dmle_extension="onelinksmenu" wr="true" icon="true" surround="true" adwords="" data-from-nav="true" data-sub-nav="true" data-items="6" custom-li-class="" custom-ul-class="" custom-a-class="" custom-inner-ul-class="" custom-nested-inner-ul-class="" custom-span-class="" navigation_id=""> <ul class="dmNavWrapper dmn menuContainer"> <li class="${li_class} desktopTopNav desktopTopNavBtnHidden dmHideFromNav navButtonLi navListLi"> <a data-href="${href}" dm_dont_rewrite_url="true" class="${a_class}" target="${a_target}" data-target-page-alias="${targetAlias}"> <span class="navItemText">${text}</span> 
</a> 
</li> 
 <li class="desktopTopNav navListLi navButtonLi"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/home?preview=true&amp;insitepreview=true&amp;dm_device=desktop#AboutUs" class="dmUDNavigationItem_010101408542" target="" data-target-page-alias="" raw_url="/site/5b24469b/home#AboutUs"> <span class="navItemText ">ABOUT US</span> 
</a> 
</li> 
 <li class="desktopTopNav navListLi navButtonLi"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/home?preview=true&amp;insitepreview=true&amp;dm_device=desktop#SpecialOffer" class="dmUDNavigationItem_010101395268" target="" data-target-page-alias="" raw_url="/site/5b24469b/home#SpecialOffer"> <span class="navItemText ">SPECIAL OFFER</span> 
</a> 
</li> 
 <li class="desktopTopNav navListLi navButtonLi"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/home?preview=true&amp;insitepreview=true&amp;dm_device=desktop#ContactUs" class="dmUDNavigationItem_010101854108" target="" data-target-page-alias="" raw_url="/site/5b24469b/home#ContactUs"> <span class="navItemText ">CONTACT US</span> 
</a> 
</li> 
 <li class="desktopTopNav navListLi navButtonLi   hasdmSub"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/for-tutors1?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101409697" target="" data-target-page-alias="" raw_url="/site/5b24469b/for-tutors1"> <span class="navItemText ">TUTORS</span> 
</a> 
 <ul class="dmNavigationStyle_1 dmNavigation dmn innerUl "> <li class="dmSub navListLi navButtonLi"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/faqs?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101372970" target="" data-target-page-alias="" raw_url="/site/5b24469b/faqs"> <span class="navItemText ">FAQs: TUTORS</span> 
</a> 
</li> 
 <li class="dmSub navListLi navButtonLi"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/sign-up-as-a-tutor?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101429671" target="" data-target-page-alias="" raw_url="/site/5b24469b/sign-up-as-a-tutor"> <span class="navItemText ">SIGN UP AS A TUTOR</span> 
</a> 
</li> 
</ul> 
</li> 
 <li class="desktopTopNav navListLi navButtonLi   hasdmSub"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/for-students-or-parents1?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101269917" target="" data-target-page-alias="" raw_url="/site/5b24469b/for-students-or-parents1"> <span class="navItemText ">FOR STUDENTS OR PARENTS</span> 
</a> 
 <ul class="dmNavigationStyle_1 dmNavigation dmn innerUl "> <li class="dmSub navListLi navButtonLi"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/copy-of-faqs?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101562672" target="" data-target-page-alias="" raw_url="/site/5b24469b/copy-of-faqs"> <span class="navItemText ">FAQs: STUDENTS/PARENTS</span> 
</a> 
</li> 
</ul> 
</li> 
 <li class="desktopTopNav navListLi navButtonLi desktopTopNavMoreBtn dmUDNavigationItem_dmMore  hasdmSub"> <a class="" target="" data-target-page-alias=""> <span class="navItemText ">MORE</span> 
</a> 
 <ul class="dmNavigationStyle_1 dmNavigation dmn innerUl "> <li class="dmSub navListLi navButtonLi"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/privacy-policy?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101437899" target="" data-target-page-alias="" raw_url="/site/5b24469b/privacy-policy"> <span class="navItemText ">PRIVACY POLICY</span> 
</a> 
</li> 
 <li class="dmSub navListLi navButtonLi"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/newpage?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101676483" target="" data-target-page-alias="" raw_url="/site/5b24469b/newpage"> <span class="navItemText ">TERMS &amp; CONDITIONS</span> 
</a> 
</li> 
</ul> 
</li> 
</ul> 
</div> 
</div> 
 <div class="u_1592195611 dmRespCol small-12 large-2 medium-2" id="1592195611"> <div class="u_1716006953 default dmSocialHub" id="1716006953" dmle_extension="social_hub" wr="false" networks="" icon="false" surround="false" data-editor="eyJ0aXRsZSI6IiIsImRpc3BsYXlUaXRsZSI6ZmFsc2UsImZvcmNlRGlzcGxheSI6ZmFsc2UsImxheW91dCI6InZlcnRpY2FsIiwibmV0d29ya3MiOlt7InVybCI6Imh0dHBzOi8vZmFjZWJvb2suY29tIiwib3JkZXIiOjAsImRlZmF1bHROZXR3b3JrIjpmYWxzZSwiaWQiOiJmYWNlYm9vayIsImljb25fY2xhc3MiOiIiLCJpY29uX2N1c3RvbSI6IiJ9LHsidXJsIjoiaHR0cDovL3d3dy5saW5rZWRpbi5jb20iLCJvcmRlciI6MSwiZGVmYXVsdE5ldHdvcmsiOmZhbHNlLCJpZCI6ImxpbmtlZGluIiwiaWNvbl9jbGFzcyI6IiIsImljb25fY3VzdG9tIjoiIn0seyJ1cmwiOiJodHRwczovL3R3aXR0ZXIuY29tLyIsIm9yZGVyIjoxNiwiZGVmYXVsdE5ldHdvcmsiOmZhbHNlLCJpZCI6InR3aXR0ZXIiLCJpY29uX2NsYXNzIjoiIiwiaWNvbl9jdXN0b20iOiIifV0sImljb25zX3N0eWxlIjoiNSIsImFsbF9wYWdlcyI6ZmFsc2V9"> <div class="socialHubWrapper"> <div class="socialHubInnerDiv vertical"> <a href="https://facebook.com/" target="_blank" dmle_dont_remove="target" dm_dont_rewrite_url="true"> <span class="dmSocialFacebook dm-icon-facebook oneIcon socialHubIcon style5"></span> 
</a> 
 <a href="http://www.linkedin.com/" target="_blank" dmle_dont_remove="target" dm_dont_rewrite_url="true"> <span class="dmSocialLinkedin icon-linkedin oneIcon socialHubIcon style5"></span> 
</a> 
 <a href="https://twitter.com/" target="_blank" dmle_dont_remove="target" dm_dont_rewrite_url="true"> <span class="dmSocialTwitter dm-icon-twitter oneIcon socialHubIcon style5"></span> 
</a> 
</div> 
</div> 
</div> 
</div> 
</div> 
</div> 
</div> 
</div> 
</div>