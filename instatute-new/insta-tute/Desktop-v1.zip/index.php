<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" class="dm-flexbox dm-flexboxlegacy dm-no-flexboxtweener dm-flexwrap pointer skrollr skrollr-desktop" style="">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<link rel="canonical" href="http://laura3.editor.multiscreensite.com/site/5b24469b/home?preview=true&amp;insitepreview=true&amp;dm_device=desktop#Home">
<meta id="view" name="viewport" content=", initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=0">
<meta name="apple-mobile-web-app-capable" content="yes">
<title>Home</title>

	<!--<link rel="icon" type="image/x-icon" href="http://laura3.editor.multiscreensite.com/favicon_d1_res.ico">-->
	

<link rel="stylesheet" type="text/css" href="d-css-foundation.min.css">

	
<!-- Google Fonts Include -->


<link rel="stylesheet" type="text/css" href="css-font-package.min.css">

<!-- RT CSS Include d-css-runtime-desktop-one-package-new-->
<link rel="stylesheet" type="text/css" href="d-css-runtime-desktop-one-package-new.min.css">

<!-- End of RT CSS Include -->



<!-- Site CSS -->
<link type="text/css" rel="stylesheet" href="5b24469b.css">
    <link type="text/css" rel="stylesheet" href="desktop.css">    
    <link type="text/css" rel="stylesheet" href="responsive.css">


<!--<style id="customWidgetStyle" type="text/css"></style>-->


        


<!--[if IE 7]><style>.fw-head.fw-logo img{max-width: 290px;}.dm_header .logo-div img{max-width: 290px;}</style><![endif]-->
<!--[if IE 8]><style>.fw-head .fw-logo img{max-width: 290px;}.dm_header .logo-div img{max-width: 290px;}*#dm div.dmHeader{_height:90px;min-height:0px;}</style><![endif]-->

<!--<link type="text/css" rel="stylesheet" href="./one.preview.css">-->


	














<!-- ========= JS Section ========= -->

<!-- Modernizr -->
<!--<script src="./cb=gapi.loaded_0" async=""></script>-->
<!--<script type="text/javascript" async="" src="recaptcha__en.js"></script>-->
<!--<script type="text/javascript" async="" src="util.js"></script>-->
<!--<script>
!function(e,n,t){function r(e,n){return typeof e===n}function s(){var e,n,t,s,o,i,a;for(var l in w)if(w.hasOwnProperty(l)){if(e=[],n=w[l],n.name&&(e.push(n.name.toLowerCase()),n.options&&n.options.aliases&&n.options.aliases.length))for(t=0;t<n.options.aliases.length;t++)e.push(n.options.aliases[t].toLowerCase());for(s=r(n.fn,"function")?n.fn():n.fn,o=0;o<e.length;o++)i=e[o],a=i.split("."),1===a.length?S[a[0]]=s:(!S[a[0]]||S[a[0]]instanceof Boolean||(S[a[0]]=new Boolean(S[a[0]])),S[a[0]][a[1]]=s),C.push((s?"":"no-")+a.join("-"))}}function o(e){var n=b.className,t=S._config.classPrefix||"";if(_&&(n=n.baseVal),S._config.enableJSClass){var r=new RegExp("(^|\\s)"+t+"no-js(\\s|$)");n=n.replace(r,"$1"+t+"js$2")}S._config.enableClasses&&(n+=" "+t+e.join(" "+t),_?b.className.baseVal=n:b.className=n)}function i(){return"function"!=typeof n.createElement?n.createElement(arguments[0]):_?n.createElementNS.call(n,"http://www.w3.org/2000/svg",arguments[0]):n.createElement.apply(n,arguments)}function a(){var e=n.body;return e||(e=i(_?"svg":"body"),e.fake=!0),e}function l(e,t,r,s){var o,l,u,d,p="modernizr",c=i("div"),m=a();if(parseInt(r,10))for(;r--;)u=i("div"),u.id=s?s[r]:p+(r+1),c.appendChild(u);return o=i("style"),o.type="text/css",o.id="s"+p,(m.fake?m:c).appendChild(o),m.appendChild(c),o.styleSheet?o.styleSheet.cssText=e:o.appendChild(n.createTextNode(e)),c.id=p,m.fake&&(m.style.background="",m.style.overflow="hidden",d=b.style.overflow,b.style.overflow="hidden",b.appendChild(m)),l=f(c,e),m.fake?(m.parentNode.removeChild(m),b.style.overflow=d,b.offsetHeight):c.parentNode.removeChild(c),!!l}function f(e,n,t){try{return e(n,t)}catch(r){return!1}}function u(e,n){return!!~(""+e).indexOf(n)}function d(e){return e.replace(/([a-z])-([a-z])/g,function(e,n,t){return n+t.toUpperCase()}).replace(/^-/,"")}function p(e,n){return function(){return e.apply(n,arguments)}}function c(e,n,t){var s;for(var o in e)if(e[o]in n)return t===!1?e[o]:(s=n[e[o]],r(s,"function")?p(s,t||n):s);return!1}function m(e){return e.replace(/([A-Z])/g,function(e,n){return"-"+n.toLowerCase()}).replace(/^ms-/,"-ms-")}function h(n,r){var s=n.length;if("CSS"in e&&"supports"in e.CSS){for(;s--;)if(e.CSS.supports(m(n[s]),r))return!0;return!1}if("CSSSupportsRule"in e){for(var o=[];s--;)o.push("("+m(n[s])+":"+r+")");return o=o.join(" or "),l("@supports ("+o+") { #modernizr { position: absolute; } }",function(e){return"absolute"==getComputedStyle(e,null).position})}return t}function y(e,n,s,o){function a(){f&&(delete j.style,delete j.modElem)}if(o=r(o,"undefined")?!1:o,!r(s,"undefined")){var l=h(e,s);if(!r(l,"undefined"))return l}for(var f,p,c,m,y,v=["modernizr","tspan"];!j.style;)f=!0,j.modElem=i(v.shift()),j.style=j.modElem.style;for(c=e.length,p=0;c>p;p++)if(m=e[p],y=j.style[m],u(m,"-")&&(m=d(m)),j.style[m]!==t){if(o||r(s,"undefined"))return a(),"pfx"==n?m:!0;try{j.style[m]=s}catch(g){}if(j.style[m]!=y)return a(),"pfx"==n?m:!0}return a(),!1}function v(e,n,t,s,o){var i=e.charAt(0).toUpperCase()+e.slice(1),a=(e+" "+P.join(i+" ")+i).split(" ");return r(n,"string")||r(n,"undefined")?y(a,n,s,o):(a=(e+" "+E.join(i+" ")+i).split(" "),c(a,n,t))}function g(e,n,r){return v(e,t,t,n,r)}var C=[],w=[],x={_version:"3.3.1",_config:{classPrefix:"dm-",enableClasses:!0,enableJSClass:!0,usePrefixes:!0},_q:[],on:function(e,n){var t=this;setTimeout(function(){n(t[e])},0)},addTest:function(e,n,t){w.push({name:e,fn:n,options:t})},addAsyncTest:function(e){w.push({name:null,fn:e})}},S=function(){};S.prototype=x,S=new S;var b=n.documentElement,_="svg"===b.nodeName.toLowerCase(),T=x.testStyles=l;T("#modernizr { height: 50vh; }",function(n){var t=parseInt(e.innerHeight/2,10),r=parseInt((e.getComputedStyle?getComputedStyle(n,null):n.currentStyle).height,10);S.addTest("cssvhunit",r==t)}),T("#modernizr { width: 50vw; }",function(n){var t=parseInt(e.innerWidth/2,10),r=parseInt((e.getComputedStyle?getComputedStyle(n,null):n.currentStyle).width,10);S.addTest("cssvwunit",r==t)});var z="Moz O ms Webkit",P=x._config.usePrefixes?z.split(" "):[];x._cssomPrefixes=P;var E=x._config.usePrefixes?z.toLowerCase().split(" "):[];x._domPrefixes=E;var N={elem:i("modernizr")};S._q.push(function(){delete N.elem});var j={style:N.elem.style};S._q.unshift(function(){delete j.style}),x.testAllProps=v,x.testAllProps=g,S.addTest("flexbox",g("flexBasis","1px",!0)),S.addTest("flexboxlegacy",g("boxDirection","reverse",!0)),S.addTest("flexboxtweener",g("flexAlign","end",!0)),S.addTest("flexwrap",g("flexWrap","wrap",!0)),s(),o(C),delete x.addTest,delete x.addAsyncTest;for(var A=0;A<S._q.length;A++)S._q[A]();e.Modernizr=S}(window,document);

</script>-->


<script>	
	var isWLR = true;
</script>

<!-- Custom Widgets js functions map -->
<script>
window.customWidgetsFunctions = {};
</script>




<script type="text/javascript">
	function buildEditorParent(){
		window.isMultiScreen = true;
		window.editorParent = {};
		window.previewParent = {};
		window.assetsCacheQueryParam="?version=2017-04-14T15_23_53";
		try {
		 var _p = window.parent;
		 if (_p && _p.document && _p.$ && _p.$.dmfw){window.editorParent = _p;}
		 else if (_p.isSitePreview){window.previewParent = _p;}
		} catch (e) {
			
		}
	}
	buildEditorParent();
</script>

<!-- Load jQuery -->
<script type="text/javascript" src="jquery.min.js"></script>
<!-- End Load jQuery -->


<script>
	window.cookiesNotificationMarkupPreview = '';
</script>
<!-- HEAD RT JS Include -->
<script>
window.INSITE = window.INSITE || {};
window.INSITE.device = "desktop";
window.rtCommonProps = {};
rtCommonProps["rt.ajax.ajaxScriptsFix"]=true;
rtCommonProps["rt.pushnotifs.sslframe.encoded"]='aHR0cHM6Ly97c3ViZG9tYWlufS5wdXNoLW5vdGlmcy5jb20=';
rtCommonProps["facebook.accessToken"]='126515034112906|8vv7JhnEegS8qz43fIOZjxGZReA';
rtCommonProps["performance.tabletPreview.removeScroll"]='false';
rtCommonProps["inlineEditGrid.snap"]=true;
rtCommonProps["popup.insite.cookie.ttl"]='0.0';
rtCommonProps["rt.pushnotifs.force.button"]=true;
rtCommonProps["google.places.key"]='AIzaSyBAwUOqPUB1CU31yDztoZYaUE7sPv4ktEI';
rtCommonProps["common.mapbox.token"]='pk.eyJ1IjoiZGFubnliMTIzIiwiYSI6ImNqMGljZ256dzAwMDAycXBkdWxwbDgzeXYifQ.Ck5P-0NKPVKAZ6SH98gxxw';
rtCommonProps["common.mapbox.js.override"]=false;
rtCommonProps["common.opencage.token"]='319e14f32bcce967ba55cd263478796d';
rtCommonProps["common.mapsProvider"]='mapbox';
rtCommonProps["common.geocodeProvider"]='opencage';
</script>

<script src="d-js-runtime-one-package.min.js"></script>


<script type="text/javascript">
  var onCaptchaLoad = function() {
    $.DM.initFormCaptcha();
  };
</script>
<!--<script src="./api.js.download" async="" defer=""></script>-->


<!-- End of HEAD RT JS Include -->
<!--<script>window.rconfWar="";</script>
<script type="text/javascript" src="wp_preview.js"></script>-->



<script src="d-js-one-runtime-layouts-package.min.js"></script>

<script src="d-js-one-runtime-layouts-desktop.min.js"></script>

<script>jQuery.DM.updateWidthAndHeight();
$(window).resize(function() {jQuery.DM.updateWidth();});
$(window).bind("orientationchange",function(e) {jQuery.DM.updateWidth();jQuery.layoutManager.initLayout();});
$(document).resize(function() {jQuery.DM.updateWidth();});
</script>




	

<!--  End render the required css and JS in the head section -->



	






<!--  <meta name="twitter:card" content="summary">

<script id="facebook-jssdk" async="" src="./facebook_all_en_US.js.download"></script>
<script src="./secureAnonymousFramework"></script>-->

<style type="text/css">.fb_hidden{position:absolute;top:-10000px;z-index:10001}.fb_reposition{overflow:hidden;position:relative}.fb_invisible{display:none}.fb_reset{background:none;border:0;border-spacing:0;color:#000;cursor:auto;direction:ltr;font-family:"lucida grande", tahoma, verdana, arial, sans-serif;font-size:11px;font-style:normal;font-variant:normal;font-weight:normal;letter-spacing:normal;line-height:1;margin:0;overflow:visible;padding:0;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;visibility:visible;white-space:normal;word-spacing:normal}.fb_reset>div{overflow:hidden}.fb_link img{border:none}@keyframes fb_transform{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}.fb_animate{animation:fb_transform .3s forwards}
.fb_dialog{background:rgba(82, 82, 82, .7);position:absolute;top:-10000px;z-index:10001}.fb_reset .fb_dialog_legacy{overflow:visible}.fb_dialog_advanced{padding:10px;-moz-border-radius:8px;-webkit-border-radius:8px;border-radius:8px}.fb_dialog_content{background:#fff;color:#333}.fb_dialog_close_icon{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 0 transparent;cursor:pointer;display:block;height:15px;position:absolute;right:18px;top:17px;width:15px}.fb_dialog_mobile .fb_dialog_close_icon{top:5px;left:5px;right:auto}.fb_dialog_padding{background-color:transparent;position:absolute;width:1px;z-index:-1}.fb_dialog_close_icon:hover{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -15px transparent}.fb_dialog_close_icon:active{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -30px transparent}.fb_dialog_loader{background-color:#f6f7f9;border:1px solid #606060;font-size:24px;padding:20px}.fb_dialog_top_left,.fb_dialog_top_right,.fb_dialog_bottom_left,.fb_dialog_bottom_right{height:10px;width:10px;overflow:hidden;position:absolute}.fb_dialog_top_left{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ye/r/8YeTNIlTZjm.png) no-repeat 0 0;left:-10px;top:-10px}.fb_dialog_top_right{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ye/r/8YeTNIlTZjm.png) no-repeat 0 -10px;right:-10px;top:-10px}.fb_dialog_bottom_left{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ye/r/8YeTNIlTZjm.png) no-repeat 0 -20px;bottom:-10px;left:-10px}.fb_dialog_bottom_right{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ye/r/8YeTNIlTZjm.png) no-repeat 0 -30px;right:-10px;bottom:-10px}.fb_dialog_vert_left,.fb_dialog_vert_right,.fb_dialog_horiz_top,.fb_dialog_horiz_bottom{position:absolute;background:#525252;filter:alpha(opacity=70);opacity:.7}.fb_dialog_vert_left,.fb_dialog_vert_right{width:10px;height:100%}.fb_dialog_vert_left{margin-left:-10px}.fb_dialog_vert_right{right:0;margin-right:-10px}.fb_dialog_horiz_top,.fb_dialog_horiz_bottom{width:100%;height:10px}.fb_dialog_horiz_top{margin-top:-10px}.fb_dialog_horiz_bottom{bottom:0;margin-bottom:-10px}.fb_dialog_iframe{line-height:0}.fb_dialog_content .dialog_title{background:#6d84b4;border:1px solid #365899;color:#fff;font-size:14px;font-weight:bold;margin:0}.fb_dialog_content .dialog_title>span{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yd/r/Cou7n-nqK52.gif) no-repeat 5px 50%;float:left;padding:5px 0 7px 26px}body.fb_hidden{-webkit-transform:none;height:100%;margin:0;overflow:visible;position:absolute;top:-10000px;left:0;width:100%}.fb_dialog.fb_dialog_mobile.loading{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ya/r/3rhSv5V8j3o.gif) white no-repeat 50% 50%;min-height:100%;min-width:100%;overflow:hidden;position:absolute;top:0;z-index:10001}.fb_dialog.fb_dialog_mobile.loading.centered{width:auto;height:auto;min-height:initial;min-width:initial;background:none}.fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner{width:100%}.fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content{background:none}.loading.centered #fb_dialog_loader_close{color:#fff;display:block;padding-top:20px;clear:both;font-size:18px}#fb-root #fb_dialog_ipad_overlay{background:rgba(0, 0, 0, .45);position:absolute;bottom:0;left:0;right:0;top:0;width:100%;min-height:100%;z-index:10000}#fb-root #fb_dialog_ipad_overlay.hidden{display:none}.fb_dialog.fb_dialog_mobile.loading iframe{visibility:hidden}.fb_dialog_content .dialog_header{-webkit-box-shadow:white 0 1px 1px -1px inset;background:-webkit-gradient(linear, 0% 0%, 0% 100%, from(#738ABA), to(#2C4987));border-bottom:1px solid;border-color:#1d4088;color:#fff;font:14px Helvetica, sans-serif;font-weight:bold;text-overflow:ellipsis;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0;vertical-align:middle;white-space:nowrap}.fb_dialog_content .dialog_header table{-webkit-font-smoothing:subpixel-antialiased;height:43px;width:100%}.fb_dialog_content .dialog_header td.header_left{font-size:12px;padding-left:5px;vertical-align:middle;width:60px}.fb_dialog_content .dialog_header td.header_right{font-size:12px;padding-right:5px;vertical-align:middle;width:60px}.fb_dialog_content .touchable_button{background:-webkit-gradient(linear, 0% 0%, 0% 100%, from(#4966A6), color-stop(.5, #355492), to(#2A4887));border:1px solid #29487d;-webkit-background-clip:padding-box;-webkit-border-radius:3px;-webkit-box-shadow:rgba(0, 0, 0, .117188) 0 1px 1px inset, rgba(255, 255, 255, .167969) 0 1px 0;display:inline-block;margin-top:3px;max-width:85px;line-height:18px;padding:4px 12px;position:relative}.fb_dialog_content .dialog_header .touchable_button input{border:none;background:none;color:#fff;font:12px Helvetica, sans-serif;font-weight:bold;margin:2px -12px;padding:2px 6px 3px 6px;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog_content .dialog_header .header_center{color:#fff;font-size:16px;font-weight:bold;line-height:18px;text-align:center;vertical-align:middle}.fb_dialog_content .dialog_content{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif) no-repeat 50% 50%;border:1px solid #555;border-bottom:0;border-top:0;height:150px}.fb_dialog_content .dialog_footer{background:#f6f7f9;border:1px solid #555;border-top-color:#ccc;height:40px}#fb_dialog_loader_close{float:left}.fb_dialog.fb_dialog_mobile .fb_dialog_close_button{text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog.fb_dialog_mobile .fb_dialog_close_icon{visibility:hidden}#fb_dialog_loader_spinner{animation:rotateSpinner 1.2s linear infinite;background-color:transparent;background-image:url(https://static.xx.fbcdn.net/rsrc.php/v3/yD/r/t-wz8gw1xG1.png);background-repeat:no-repeat;background-position:50% 50%;height:24px;width:24px}@keyframes rotateSpinner{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
.fb_iframe_widget{display:inline-block;position:relative}.fb_iframe_widget span{display:inline-block;position:relative;text-align:justify}.fb_iframe_widget iframe{position:absolute}.fb_iframe_widget_fluid_desktop,.fb_iframe_widget_fluid_desktop span,.fb_iframe_widget_fluid_desktop iframe{max-width:100%}.fb_iframe_widget_fluid_desktop iframe{min-width:220px;position:relative}.fb_iframe_widget_lift{z-index:1}.fb_hide_iframes iframe{position:relative;left:-10000px}.fb_iframe_widget_loader{position:relative;display:inline-block}.fb_iframe_widget_fluid{display:inline}.fb_iframe_widget_fluid span{width:100%}.fb_iframe_widget_loader iframe{min-height:32px;z-index:2;zoom:1}.fb_iframe_widget_loader .FB_Loader{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif) no-repeat;height:32px;width:32px;margin-left:-16px;position:absolute;left:50%;z-index:4}</style></head>






<body id="dmRoot" class="supportsFontIcons dmRoot dmResellerSite dmDesktopBody dmLargeBody  pcCustomScrollbar d1SiteBody dmBodyNoIscroll fullyLoaded" style="overflow: auto; padding: 0px; margin: 0px; float: left; min-width: 1349px;">




<div id="disabledImageZone" style="z-index: 100000; position: absolute; left: 683px; top: 296.5px;;display: none !important">
<style type="text/css">
	#imageZone{position:absolute;margin:auto;}
	.coloumns{border-radius:3px;background-color:rgb(249,152,13);/*border:1px solid #999;*/ height:18px;width:6px;-webkit-animation-name:loader;-webkit-animation-duration:1s;-webkit-animation-iteration-count:infinite;-webkit-animation-direction:linear;-moz-animation-name:loader;-moz-animation-duration:1s;-moz-animation-iteration-count:infinite;-moz-animation-direction:linear;opacity:.25;-webkit-transform:scale(0.7);-webkit-transform-origin:50% 180%;-moz-transform:scale(0.7);-moz-transform-origin:50% 180%;position:absolute;}
	#coloumn1{-webkit-transform:rotate(0deg);-webkit-animation-delay:-.914s;-moz-transform:rotate(0deg);-moz-animation-delay:-.914s;}
	#coloumn2{-webkit-transform:rotate(30deg);-webkit-animation-delay:-.831s;-moz-transform:rotate(30deg);-moz-animation-delay:-.831s;}
	#coloumn3{-webkit-transform:rotate(60deg);-webkit-animation-delay:-.747s;-moz-transform:rotate(60deg);-moz-animation-delay:-.747s;}
	#coloumn4{-webkit-transform:rotate(90deg);-webkit-animation-delay:-.664s;-moz-transform:rotate(90deg);-moz-animation-delay:-.664s;}
	#coloumn5{-webkit-transform:rotate(120deg);-webkit-animation-delay:-.581s;-moz-transform:rotate(120deg);-moz-animation-delay:-.581s;}
	#coloumn6{-webkit-transform:rotate(150deg);-webkit-animation-delay:-.498s;-moz-transform:rotate(150deg);-moz-animation-delay:-.498s;}
	#coloumn7{-webkit-transform:rotate(180deg);-webkit-animation-delay:-.415s;-moz-transform:rotate(180deg);-moz-animation-delay:-.415s;}
	#coloumn8{-webkit-transform:rotate(210deg);-webkit-animation-delay:-.332s;-moz-transform:rotate(210deg);-moz-animation-delay:-.332s;}
	#coloumn9{-webkit-transform:rotate(240deg);-webkit-animation-delay:-.249s;-moz-transform:rotate(240deg);-moz-animation-delay:-.249s;}
	#coloumn10{-webkit-transform:rotate(270deg);-webkit-animation-delay:-.166s;-moz-transform:rotate(270deg);-moz-animation-delay:-.166s;}
	#coloumn11{-webkit-transform:rotate(300deg);-webkit-animation-delay:-.083s;-moz-transform:rotate(300deg);-moz-animation-delay:-.083s;}
	#coloumn12{-webkit-transform:rotate(330deg);-moz-transform:rotate(330deg);}
	@-webkit-keyframes loader {0%{opacity:1;}100%{opacity:.25;}}
	@-moz-keyframes loader {0%{opacity:1;}100%{opacity:.25;}}
</style>
<div id="imageZone"><div id="coloumn1" class="coloumns" style="height: 10px; width: 3px; background-color: rgb(0, 17, 17);"></div><div id="coloumn2" class="coloumns" style="height: 10px; width: 3px; background-color: rgb(0, 17, 17);"></div><div id="coloumn3" class="coloumns" style="height: 10px; width: 3px; background-color: rgb(0, 17, 17);"></div><div id="coloumn4" class="coloumns" style="height: 10px; width: 3px; background-color: rgb(0, 17, 17);"></div><div id="coloumn5" class="coloumns" style="height: 10px; width: 3px; background-color: rgb(0, 17, 17);"></div><div id="coloumn6" class="coloumns" style="height: 10px; width: 3px; background-color: rgb(0, 17, 17);"></div><div id="coloumn7" class="coloumns" style="height: 10px; width: 3px; background-color: rgb(0, 17, 17);"></div><div id="coloumn8" class="coloumns" style="height: 10px; width: 3px; background-color: rgb(0, 17, 17);"></div><div id="coloumn9" class="coloumns" style="height: 10px; width: 3px; background-color: rgb(0, 17, 17);"></div><div id="coloumn10" class="coloumns" style="height: 10px; width: 3px; background-color: rgb(0, 17, 17);"></div><div id="coloumn11" class="coloumns" style="height: 10px; width: 3px; background-color: rgb(0, 17, 17);"></div><div id="coloumn12" class="coloumns" style="height: 10px; width: 3px; background-color: rgb(0, 17, 17);"></div>
</div></div>

<!-- ========= Site Content ========= -->
<div id="dm" class="dmwr">
<div class="dm_wrapper standard-var5 widgetStyle-3 standard"> 
 <div dmwrapped="true" id="1901957768" class="dm-home-page" themewaschanged="true"> <div dmtemplateid="StandardLayoutMultiD" class="standardHeaderLayout dm-bfs hasAnimations hasStickyHeader dmPageBody dmFreeHeader dm-layout-home d-page-1716942098" id="dm-outer-wrapper" data-page-class="1716942098" data-buttonstyle="ROUND_SIDES" data-soch="true" data-background-size="cover" data-background-attachment="fixed" data-background-repeat="no-repeat" data-background-position="50% 0%" data-background-hide-inner="true" data-background-fullbleed="false" data-background-parallax-selector=".dmSectionParallex" data-background-parallax-speed="0.2"> <div id="dmStyle_outerContainer" class="dmOuter"> <div id="dmStyle_innerContainer" class="dmInner" style="min-height: 544px;"> <div class="dmLayoutWrapper standard-var dmStandardDesktop"> <div id="hiddenNavPlaceHolder" class="hiddenNavPlaceHolder navPlaceHolder dmDisplay_None dmn dmLayoutNav"> <ul class="dmNav dmNavCustom dmn dmMobile_navNoIcons dmTablet_navNoIcons default" id="dmNav" dmnavfullyann="true" shape_class="default" exp_align="right" exp_nps="true" exp_npt="false" exp_hmi="false" exp_hma="false" exp_btn_mnutitle="Menu" btmtitle="Back to menu" mmtitle="Main Menu" hwa="false" dmmoreicon="icon-angle-down" dmlessicon="icon-angle-up" dmhomeicon="icon-home" design_classes="dmMobile_navNoIcons dmTablet_navNoIcons" style="display: block"> <li class="p_list_item dmUDNavigationItem_00_li dmHideFromNav-mobile dmHideFromNav-tablet dmHideFromNav-desktop" id="dm_navGroup00_item" dmnav_annotate="title_changed;" nav_hidden-mobile="true" nav_hidden-tablet="true" nav_hidden-desktop="true"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/home?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_00 dm_navGroup00a" id="dm_navGroup00a" icon-name="icon-home" raw_url="/site/5b24469b/home"> <div class="navIconBg" id="1959256709"> <div class="navIcon navItemIcon" id="dm_navGroup00icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup00div">Home</div> 
 <div class="navArrowBg" id="1232673487"> <div class="navArrow" id="1523839124"></div> 
 <div class="navArrowBottom" id="1817920035"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup00s"></ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_010101408542_li dmNavShownItem" id="dm_navGroup010101408542_item" dmnav_annotate="inserted;"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/home?preview=true&amp;insitepreview=true&amp;dm_device=desktop#AboutUs" class="dmUDNavigationItem_010101408542 dm_navGroup010101408542a" icon-name="icon-star" id="dm_navGroup010101408542a" raw_url="/site/5b24469b/home#AboutUs"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101408542icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101408542div">ABOUT US</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup010101408542s"></ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_010101296766_li dmHideFromNav-desktop dmHideFromNav-tablet dmHideFromNav-mobile" id="dm_navGroup010101296766_item" dmnav_annotate="inserted;" nav_hidden-desktop="true" nav_hidden-tablet="true" nav_hidden-mobile="true"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/home?preview=true&amp;insitepreview=true&amp;dm_device=desktop#Testimonials" class="dmUDNavigationItem_010101296766 dm_navGroup010101296766a" icon-name="icon-star" id="dm_navGroup010101296766a" raw_url="/site/5b24469b/home#Testimonials"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101296766icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101296766div">TESTIMONIALS</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup010101296766s"></ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_010101395268_li dmNavShownItem" id="dm_navGroup010101395268_item" dmnav_annotate="inserted;"> 
     <a href="#" class="dmUDNavigationItem_010101395268 dm_navGroup010101395268a" icon-name="icon-star" id="dm_navGroup010101395268a" raw_url="/site/5b24469b/home#SpecialOffer"> 
         <div class="navIconBg"> 
             <div class="navIcon navItemIcon" id="dm_navGroup010101395268icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101395268div">SPECIAL OFFER</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup010101395268s"></ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_010101854108_li dmNavShownItem" id="dm_navGroup010101854108_item" dmnav_annotate="inserted;"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/home?preview=true&amp;insitepreview=true&amp;dm_device=desktop#ContactUs" class="dmUDNavigationItem_010101854108 dm_navGroup010101854108a" icon-name="icon-star" id="dm_navGroup010101854108a" raw_url="/site/5b24469b/home#ContactUs"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101854108icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101854108div">CONTACT US</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup010101854108s"></ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_010101409697_li dmNavShownItem" id="dm_navGroup010101409697_item" dmnav_annotate="inserted;"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/for-tutors1?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101409697 dm_navGroup010101409697a" icon-name="dm-icon-w_email" id="dm_navGroup010101409697a" raw_url="/site/5b24469b/for-tutors1"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101409697icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101409697div">TUTORS</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="dmNav" id="dm_navGroup010101409697s"> <li class="p_list_item dmUDNavigationItem_010101372970_li" id="dm_navGroup010101372970_item" dmnav_annotate="inserted;"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/faqs?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101372970 dm_navGroup010101372970a" icon-name="dm-icon-page-list" id="dm_navGroup010101372970a" raw_url="/site/5b24469b/faqs"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101372970icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101372970div">FAQs: TUTORS</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup010101372970s"></ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_010101429671_li" id="dm_navGroup010101429671_item" dmnav_annotate="inserted;"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/sign-up-as-a-tutor?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101429671 dm_navGroup010101429671a" icon-name="dm-icon-w_email" id="dm_navGroup010101429671a" raw_url="/site/5b24469b/sign-up-as-a-tutor"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101429671icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101429671div">SIGN UP AS A TUTOR</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup010101429671s"></ul> 
</li> 
</ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_010101269917_li dmNavShownItem" id="dm_navGroup010101269917_item" dmnav_annotate="inserted;"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/for-students-or-parents1?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101269917 dm_navGroup010101269917a" icon-name="icon-star" id="dm_navGroup010101269917a" raw_url="/site/5b24469b/for-students-or-parents1"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101269917icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101269917div">FOR STUDENTS OR PARENTS</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="dmNav" id="dm_navGroup010101269917s"> <li class="p_list_item dmUDNavigationItem_010101562672_li" id="dm_navGroup010101562672_item" dmnav_annotate="inserted;"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/copy-of-faqs?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101562672 dm_navGroup010101562672a" icon-name="icon-star" id="dm_navGroup010101562672a" raw_url="/site/5b24469b/copy-of-faqs"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101562672icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101562672div">FAQs: STUDENTS/PARENTS</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup010101562672s"></ul> 
</li> 
</ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_010101631964_li dmHideFromNav-desktop dmHideFromNav-tablet dmHideFromNav-mobile" id="dm_navGroup010101631964_item" dmnav_annotate="inserted;" nav_hidden-desktop="true" nav_hidden-tablet="true" nav_hidden-mobile="true"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/disclaimer1?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101631964 dm_navGroup010101631964a" icon-name="dm-icon-blank" id="dm_navGroup010101631964a" raw_url="/site/5b24469b/disclaimer1"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101631964icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101631964div">DISCLAIMER</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup010101631964s"></ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_010101437899_li dmNavShownItem" id="dm_navGroup010101437899_item" dmnav_annotate="inserted;"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/privacy-policy?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101437899 dm_navGroup010101437899a" icon-name="icon-star" id="dm_navGroup010101437899a" raw_url="/site/5b24469b/privacy-policy"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101437899icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101437899div">PRIVACY POLICY</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup010101437899s"></ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_010101676483_li dmNavShownItem" id="dm_navGroup010101676483_item" dmnav_annotate="inserted;"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/newpage?preview=true&amp;insitepreview=true&amp;dm_device=desktop" class="dmUDNavigationItem_010101676483 dm_navGroup010101676483a" icon-name="icon-star" id="dm_navGroup010101676483a" raw_url="/site/5b24469b/newpage"> <div class="navIconBg"> <div class="navIcon navItemIcon" id="dm_navGroup010101676483icon"></div> 
</div> 
 <div class="navText" id="dm_navGroup010101676483div">TERMS &amp; CONDITIONS</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dm_navGroup010101676483s"></ul> 
</li> 
</ul> 
 <ul class="dmNav dmNavCustom dmn"> <li class="p_list_item dmUDNavigationItem_dmMore_li dmHideFromNav" id="dmMore"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/home?preview=true&amp;insitepreview=true&amp;dm_device=desktop#" class="dmUDNavigationItem_dmMore dmMorea" icon-name="icon-angle-down" id="dmMorea"> <div class="navIconBg"> <div class="navIcon hasFontIcon fontIconName" id="dmMoreicon"></div> 
</div> 
 <div class="navText" id="dmMorediv">MORE</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dmMores"></ul> 
</li> 
 <li class="p_list_item dmUDNavigationItem_dmLess_li dmHideFromNav" id="dmLess"> <a href="http://laura3.editor.multiscreensite.com/site/5b24469b/home?preview=true&amp;insitepreview=true&amp;dm_device=desktop#" class="dmUDNavigationItem_dmLess dmLessa" icon-name="icon-angle-up" id="dmLessa"> <div class="navIconBg"> <div class="navIcon hasFontIcon fontIconName" id="dmLessicon"></div> 
</div> 
 <div class="navText" id="dmLessdiv">LESS</div> 
 <div class="navArrowBg"> <div class="navArrow"></div> 
 <div class="navArrowBottom"></div> 
</div> 
</a> 
 <ul class="" id="dmLesss"></ul> 
</li> 
</ul> 
</div> 
 <div> 

     <?php //include('mobile_menu.php'); ?>

     <div id="iscrollBody"> 
         <div id="site_content"> 
             <?php include('desktop_menu.php'); ?>
             
              
             
             
 <div class="stickyHeaderSpacer" id="stickyHeaderSpacer" data-new="true"></div> 
 <div class="dmRespRow dmRespRowStable dmRespRowNoPadding dmPageTitleRow "> <div class="dmRespColsWrapper"> <div class="large-12 dmRespCol"> <div id="innerBar" class="innerBar lineInnerBar dmDisplay_None"> <div class="titleLine display_None"><hr></div> 
<!-- Page title is hidden in css for new responsive sites. It is left here only so we don't break old sites. Don't copy it to new layouts --> <div id="pageTitleText"><div class="innerPageTitle">Home</div></div> 
 <div class="titleLine display_None"><hr></div> 
</div> 
</div> 
</div> 
</div> 
 <div dmwrapped="true" id="dmTempContainer" class="dmBody u_dmStyle_template_home dm-home-page" themewaschanged="true" style="transition: -webkit-transform 0s cubic-bezier(0.1, 0.1, 0.25, 0.9), opacity cubic-bezier(0.1, 0.1, 0.25, 0.9); transform: none; width: 1183px; height: 800px; position: absolute; top: 0px; display: none; opacity: 1;"></div><div dmwrapped="true" id="dmFirstContainer" class="dmBody u_dmStyle_template_home dm-home-page" themewaschanged="true" style="transition: -webkit-transform 0s cubic-bezier(0.1, 0.1, 0.25, 0.9), opacity cubic-bezier(0.1, 0.1, 0.25, 0.9); transform: none; opacity: 1; display: block; top: 0px;"> <div id="allWrapper" class="allWrapper"><!-- navigation placeholders --> <div id="navWrapper" class="navWrapper"> <div id="hiddenNavPlaceHolder" class="hiddenNavPlaceHolder navPlaceHolder dmDisplay_None" navplaceholder="true"></div> 
 <div id="backToHomePlaceHolder" class="backToHomePlaceHolder navPlaceHolder" navplaceholder="true"></div> 
 <div id="newNavigationElementPlaceHolder" class="newNavigationElementPlaceHolder navPlaceHolder" navplaceholder="true"></div> 
 <div id="newNavigationSubNavPlaceHolder" class="newNavigationSubNavPlaceHolder navPlaceHolder" navplaceholder="true"></div> 
</div> 
 <div id="dm_content" class="dmContent"> <div dm:templateorder="170" class="dmHomeRespTmpl mainBorder dmRespRowsWrapper dmFullRowRespTmpl dmRespRowsWrapperSize1" id="1716942098" style="min-height: 237px;"> <div class="u_Home dmRespRow hasBackgroundOverlay dmSectionParallaxNew" style="text-align: center;" id="Home" data-anchor="Home"> <div class="dmRespColsWrapper u_1568127116" id="1568127116"> <div class="dmRespCol small-12 u_1414742659 medium-12 large-12 content-removed" id="1414742659"> <span id="1346630203"></span> 
 <h1 class="u_1060925900 dmNewParagraph" id="1060925900" data-uialign="center"><div style="text-align: center;"><span style="color: rgb(255, 255, 255); background-color: rgba(0, 0, 0, 0);" class="m-size-36 lh-1 size-80">We link experts to learners in need.</span></div></h1> <h4 class="u_1932257932 dmNewParagraph" id="1932257932" style="display: block;" data-uialign="center"><div style="text-align: center;"><font color="#ffffff"><span style="font-weight: 300;">Innovative Tutoring in Mathematics, Chemistry and Biology</span></font></div></h4> <a data-display-type="block" class="u_1918342143 dmButtonLink dmWidget dmWwr default dmOnlyButton dmDefaultGradient hide-for-small" file="false" href="http://laura3.editor.multiscreensite.com/site/5b24469b/for-tutors1?preview=true&amp;insitepreview=true&amp;dm_device=desktop" id="1918342143" dm_dont_rewrite_url="false" data-buttonstyle="THICK_BORDER_ROUND" raw_url="/site/5b24469b/for-tutors1"> <span class="iconBg u_1826720994" id="1826720994"> <span class="icon hasFontIcon icon-star u_1256167524" id="1256167524"></span> 
</span> 
 <span class="text u_1740037692" id="1740037692">I AM A TUTOR</span> 
</a> 
 <a data-display-type="block" class="u_1418773867 dmButtonLink dmWidget dmWwr default dmOnlyButton dmDefaultGradient hide-for-small" file="false" href="http://laura3.editor.multiscreensite.com/site/5b24469b/for-students-or-parents1?preview=true&amp;insitepreview=true&amp;dm_device=desktop" id="1418773867" dm_dont_rewrite_url="false" data-buttonstyle="THICK_BORDER_ROUND" raw_url="/site/5b24469b/for-students-or-parents1"> <span class="iconBg u_1293370550" id="1293370550"> <span class="icon hasFontIcon icon-star u_1601551693" id="1601551693"></span> 
</span> 
 <span class="text u_1954676364" id="1954676364">I AM A TEACHER OR STUDENT</span> 
</a> 
</div> 
</div> 
</div> 
 <div class="dmRespRow u_WhyTutoring" style="text-align: center;" id="WhyTutoring" data-anchor="Why Tutoring"> <div class="dmRespColsWrapper" id="1465921196"> <div class="dmRespCol small-12 medium-12 large-12" id="1643813231"> <h2 class="u_1484083695 dmNewParagraph" id="1484083695" data-uialign="center" style="display: block;"><div style=";text-align: center;"><span style=";color: rgb(255, 255, 255);"></span></div><div style=";text-align: left;"><span style=";color: rgb(255, 255, 255);"></span></div><span><div style="text-align: center;">What is Insta-tute?</div></span><div style=";text-align: left;"><span style=";color: rgb(255, 255, 255);"></span></div></h2> <div class="u_1631186053 dmNewParagraph" data-dmtmpl="true" id="1631186053" data-editor-state="closed" data-uialign="center" style="display: block;"><div style="text-align: center; font-family: inherit;"><font color="#333333"><span style="font-size: 18px;"><br></span></font></div><div style="text-align: center; font-family: inherit;"><font color="#333333"><span style="font-size: 18px;">Insta-tute is a web and app-based platform for students to seek and secure top-performing, peer-reviewed tutors for any subjects including primary, secondary and university curricula as well as extra-curricular activities.&nbsp;</span></font></div><div style="text-align: center; font-family: inherit;"><font color="#333333"><span style="font-size: 18px;"><br></span></font></div><div style="text-align: center; font-family: inherit;"><font color="#333333"><span style="font-size: 18px;">Our tutors come from a wide variety of backgrounds - we have primary and secondary school teachers, university lecturers and students, even stay-at-home parents.&nbsp;</span></font></div></div></div> 
</div> 
</div> 
 <div class="dmRespRow" style="text-align: center;" id="1254910785"> <div class="dmRespColsWrapper" id="1129403468"> <div class="dmRespCol small-12 medium-12 large-12" id="1492835062"> <span id="1572770838"></span> 
 <div class="dmDividerWrapper clearfix" id="1355243603"><hr class="dmDivider" style="min-height: 2px; border:none; background:grey" id="1654191923"></div> 
</div> 
</div> 
</div> 
 <div class="dmRespRow" style="text-align: center;" id="1657893515"> <div class="dmRespColsWrapper" id="1628378997"> <div class="dmRespCol small-12 medium-12 large-12" id="1053312410"> <span id="1872740084"></span> 
 <h2 class="u_1700347418 dmNewParagraph" id="1700347418" data-uialign="center" style="display: block;"><div style=";text-align: center;"><span style=";color: rgb(255, 255, 255);"></span></div><div style=";text-align: left;"><span style=";color: rgb(255, 255, 255);"></span></div><span><div style="text-align: center;">What are the subjects?</div></span><div style=";text-align: left;"><span style=";color: rgb(255, 255, 255);"></span></div></h2></div> 
</div> 
</div> 
 <div class="u_1621667418 dmRespRow wow fadeInUp animated" style="text-align: center; visibility: visible; animation-name: fadeInUp;" id="1621667418" mode="1" data-anim-desktop="fadeInUp"> <div class="dmRespColsWrapper" id="1058775737"> <div class="u_1624058868 dmRespCol large-2 medium-2 small-12 emptyColumn" id="1624058868"> <span id="1016376050"></span> 
 <div class="u_1682202526 graphicWidget" editablewidget="true" data-widget-type="graphic" id="1682202526" data-layout="graphic-style-2"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1792 1792" id="1332207812" class="svg u_1332207812" data-icon-name="fa-calculator"> <path fill="inherit" d="M384 1536q0-53-37.5-90.5t-90.5-37.5-90.5 37.5-37.5 90.5 37.5 90.5 90.5 37.5 90.5-37.5 37.5-90.5zM768 1536q0-53-37.5-90.5t-90.5-37.5-90.5 37.5-37.5 90.5 37.5 90.5 90.5 37.5 90.5-37.5 37.5-90.5zM384 1152q0-53-37.5-90.5t-90.5-37.5-90.5 37.5-37.5 90.5 37.5 90.5 90.5 37.5 90.5-37.5 37.5-90.5zM1152 1536q0-53-37.5-90.5t-90.5-37.5-90.5 37.5-37.5 90.5 37.5 90.5 90.5 37.5 90.5-37.5 37.5-90.5zM768 1152q0-53-37.5-90.5t-90.5-37.5-90.5 37.5-37.5 90.5 37.5 90.5 90.5 37.5 90.5-37.5 37.5-90.5zM384 768q0-53-37.5-90.5t-90.5-37.5-90.5 37.5-37.5 90.5 37.5 90.5 90.5 37.5 90.5-37.5 37.5-90.5zM1152 1152q0-53-37.5-90.5t-90.5-37.5-90.5 37.5-37.5 90.5 37.5 90.5 90.5 37.5 90.5-37.5 37.5-90.5zM768 768q0-53-37.5-90.5t-90.5-37.5-90.5 37.5-37.5 90.5 37.5 90.5 90.5 37.5 90.5-37.5 37.5-90.5zM1536 1536v-384q0-52-38-90t-90-38-90 38-38 90v384q0 52 38 90t90 38 90-38 38-90zM1152 768q0-53-37.5-90.5t-90.5-37.5-90.5 37.5-37.5 90.5 37.5 90.5 90.5 37.5 90.5-37.5 37.5-90.5zM1536 448v-256q0-26-19-45t-45-19h-1280q-26 0-45 19t-19 45v256q0 26 19 45t45 19h1280q26 0 45-19t19-45zM1536 768q0-53-37.5-90.5t-90.5-37.5-90.5 37.5-37.5 90.5 37.5 90.5 90.5 37.5 90.5-37.5 37.5-90.5zM1664 128v1536q0 52-38 90t-90 38h-1408q-52 0-90-38t-38-90v-1536q0-52 38-90t90-38h1408q52 0 90 38t38 90z" id="1509863426"></path> 
</svg> 
</div> 
</div> 
 <div class="u_1888865284 dmRespCol large-4 medium-4 small-12" id="1888865284"> <span id="1989954267"></span> 
 <h4 class="dmNewParagraph" id="1948240077" data-uialign="center"><div style="text-align: center;"><b style="background-color: transparent;">Mathematics</b></div></h4> <div class="u_1651816567 dmNewParagraph" data-dmtmpl="true" id="1651816567" data-editor-state="closed" data-uialign="center" style="display: block;"><div style="text-align: center;"><font color="#333333">The staff at Tutoring are all trained professionals who excel in their field. Many of our educators also have supplement training in alternative learning strategies.</font></div></div></div> 
 <div class="u_1223656703 dmRespCol large-2 medium-2 small-12 emptyColumn" id="1223656703"> <span id="1318286229"></span> 
 <div class="u_1761893276 graphicWidget" editablewidget="true" data-widget-type="graphic" id="1761893276" data-layout="graphic-style-2"> <svg viewBox="0 0 100 100" id="1325609919" class="svg u_1325609919" data-icon-name="li-pencil"> <path d="M50,15.5c-6.7,0-12.2,5.5-12.2,12.2v44.7L50,84.5l12.2-12.2V27.7C62.2,20.9,56.7,15.5,50,15.5z M40.8,72.2
	c2.8-1.2,5.9-0.9,8.6,0.6l0.6,0.3l0.6-0.3c2.7-1.6,5.8-1.8,8.6-0.6l-4.1,4.1H44.9L40.8,72.2z M50,70.6c-3.2-1.6-6.7-1.8-10-0.5V39.8
	H60v30.3C56.7,68.8,53.2,69,50,70.6z M60,28.8v8.8H40v-8.8H60z M50,17.7c5.1,0,9.3,3.9,9.8,8.8H40.2C40.7,21.6,44.9,17.7,50,17.7z
	 M47.1,78.5h5.7L50,81.4L47.1,78.5z" id="1165489656"></path> 
</svg> 
</div> 
</div> 
 <div class="u_1057941779 dmRespCol large-4 medium-4 small-12" id="1057941779"> <span id="1279941920"></span> 
 <h4 class="dmNewParagraph" id="1090866805" data-uialign="center"><div style="text-align: center;"><b style="background-color: transparent;">English &amp; Grammar</b></div></h4> <div class="u_1774616981 dmNewParagraph" data-dmtmpl="true" id="1774616981" data-editor-state="closed" data-uialign="center" style="display: block;"><div style="text-align: center;"><font color="#333333">The Tutoring teaching method is based on an innovative and result-oriented technique that helps students overcome barriers to bring concrete results.&nbsp;</font></div></div></div> 
</div> 
</div> 
 <div class="u_1076961848 dmRespRow wow fadeInUp animated" style="text-align: center; visibility: visible; animation-name: fadeInUp;" id="1076961848" data-anim-desktop="fadeInUp"> <div class="dmRespColsWrapper" id="1077523531"> <div class="u_1183180535 dmRespCol small-12 large-2 medium-2 emptyColumn" id="1183180535"> <span id="1794410345"></span> 
 <div class="u_1084771456 graphicWidget" editablewidget="true" data-widget-type="graphic" id="1084771456" data-layout="graphic-style-2"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 70 70" id="1374093366" class="svg u_1374093366" data-icon-name="wp-location_map_thin"> <g id="1495542972"> <path d="M60,58.7l-5-18c-0.1-0.3-0.3-0.5-0.6-0.6l-9-4C45.2,36,45,36,44.8,36l-3,0.7c-0.5,0.8-0.9,1.5-1.3,2.3l3.5-0.8v6.1l-16,7.1
		l0-9.7l2.5-0.5c-0.2-0.6-0.5-1.3-0.8-1.9L27.1,40l-8.7-3.9c-0.2-0.1-0.5-0.1-0.8,0c-0.3,0.1-0.4,0.3-0.6,0.5l-7,17
		c-0.1,0.3-0.1,0.6,0,0.8c0.1,0.3,0.3,0.4,0.6,0.5l16,5c0.2,0.1,0.4,0.1,0.6,0L45,55l13.7,4.9c0.1,0,0.2,0.1,0.3,0.1
		c0.2,0,0.5-0.1,0.7-0.3C60,59.5,60.1,59.1,60,58.7z M18.5,38.3l7.5,3.3l0,8.9l-8.9-8.9L18.5,38.3z M12.3,53.4l4-9.6l9.7,9.7v4.2
		L12.3,53.4z M44,53.2l-16,4.4v-4l16-7.1V53.2z M55.5,50.1l-6-6l3.8-1.7L55.5,50.1z M46,38.5l5.5,2.5L46,43.5V38.5z M46,53.3v-7.6
		l1.5-0.7l9,9l1,3.4L46,53.3z" id="1882715872"></path> 
 <path d="M35,45c-0.8,0-1.3-0.5-1.6-1.5l0-0.1l-0.7-2.5c-1.3-3.7-3.6-7.5-6.7-11.1c-1.9-2.2-3-5-3-7.9C23,15.3,28.4,10,35,10
		c6.6,0,12,5.3,12,11.9c0,2.9-1.1,5.7-3,7.9c-3.1,3.6-5.4,7.3-6.7,11.1l-0.7,2.5C36.3,44.5,35.8,45,35,45z M35,12
		c-5.5,0-10,4.5-10,9.9c0,2.4,0.9,4.8,2.5,6.6c3.3,3.8,5.7,7.7,7.1,11.8l0.4,1.5l0.4-1.5c1.4-4.1,3.8-8.1,7.1-11.9
		c1.6-1.8,2.5-4.2,2.5-6.6C45,16.5,40.5,12,35,12z" id="1407630241"></path> 
 <path d="M35,27c-2.8,0-5-2.2-5-5s2.2-5,5-5c2.8,0,5,2.2,5,5S37.8,27,35,27z M35,19c-1.7,0-3,1.3-3,3s1.3,3,3,3c1.7,0,3-1.3,3-3
		S36.7,19,35,19z" id="1857872562"></path> 
</g> 
</svg> 
</div> 
</div> 
 <div class="u_1594073485 dmRespCol small-12 large-4 medium-4" id="1594073485"> <span id="1624317378"></span> 
 <h4 class="dmNewParagraph" id="1959790497" data-uialign="center"><div style="text-align: center;"><b style="background-color: transparent;">Geography</b></div></h4> <div class="u_1303223582 dmNewParagraph" data-dmtmpl="true" id="1303223582" data-editor-state="closed" data-uialign="center" style="display: block;"><div style="text-align: center;"><span style="background-color: transparent;">Some people learn best on their own; others prefer learning in groups. At Tutoring, you can choose the environment that works best for you.&nbsp;</span></div><div style="text-align: left;"><span style="color: rgb(51, 51, 51);"></span></div></div></div> 
 <div class="u_1004506918 dmRespCol small-12 large-2 medium-2 emptyColumn" id="1004506918"> <span id="1843528492"></span> 
 <div class="u_1717955564 graphicWidget" editablewidget="true" data-widget-type="graphic" id="1717955564" data-layout="graphic-style-2"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" id="1080676184" class="svg u_1080676184" data-icon-name="li-computer_screen"> <path d="M85.8,9.7H22c-3.4,0-6.1,2.8-6.1,6.1v51.6c0,3.4,2.8,6.1,6.1,6.1h18.4v9.8H29.3v2.5h49.1v-2.5H67.4v-9.8h18.4
	c3.4,0,6.1-2.8,6.1-6.1V15.8C92,12.4,89.2,9.7,85.8,9.7z M22,12.1h63.9c2,0,3.7,1.7,3.7,3.7v43H18.3v-43
	C18.3,13.8,19.9,12.1,22,12.1z M64.9,83.3H42.8v-9.8h22.1V83.3z M85.8,71.1H22c-2,0-3.7-1.7-3.7-3.7v-6.1h71.2v6.1
	C89.5,69.4,87.8,71.1,85.8,71.1z" id="1377461993"></path> 
</svg> 
</div> 
</div> 
 <div class="u_1022341063 dmRespCol small-12 large-4 medium-4" id="1022341063"> <span id="1815033243"></span> 
 <h4 class="dmNewParagraph" id="1847340825" style="" data-uialign="center"><div style="text-align: center;"><b style="background-color: transparent;">Information Technology</b></div></h4> <div class="u_1556770158 dmNewParagraph" data-dmtmpl="true" id="1556770158" data-editor-state="closed" data-uialign="center" style="display: block;"><div style="text-align: center;"><span style="color: rgb(51, 51, 51);">Every lesson is 45 minutes long, for optimal effectiveness. You can have one or two sessions per week, depending upon your need and availability.</span></div></div></div> 
</div> 
</div> 
 <div class="u_AboutUs dmRespRow dmSectionParallaxNew fullBleedChanged fullBleedMode" style="text-align: center;" id="AboutUs" data-anchor="About Us"> <div class="dmRespColsWrapper" id="1071636935"> <div class="dmRespCol small-12 medium-6 large-6 u_1094029783 emptyColumn" id="1094029783"> <div class="u_1004567458 dmSpacer" id="1004567458"></div> 
</div> 
 <div class="u_1279708004 dmRespCol small-12 medium-6 large-6" id="1279708004"> <h2 class="u_1823686917 dmNewParagraph" id="1823686917" data-uialign="center" style=""><div style=";text-align: center;"><span style=";color: rgb(255, 255, 255);"></span></div><div style=";text-align: left;"><span style=";color: rgb(255, 255, 255);"></span></div><span><div style="text-align: left;">About Insta-tute</div></span><div style=";text-align: left;"><span style=";color: rgb(255, 255, 255);"></span></div></h2> <div class="u_1531782231 dmDividerWrapper clearfix" id="1531782231" layout="divider-style-1"><hr class="dmDivider" style="min-height: 2px; border:none; background:grey" id="1717814423"></div> 
 <div class="u_1650871116 dmNewParagraph" data-dmtmpl="true" id="1650871116" data-editor-state="closed" data-uialign="left" style="display: block;"><div style="text-align: left; font-family: inherit;"><font color="#333333">As a banker, married to a senior educator, we saw that there were a lack of options to find good quality tutors. The options were limited to expensive colleges, random phone numbers on telephone poles, or word-of-mouth. Only the last option could be highly trusted, however there was that risk that the tutor wasn't suitable for you.</font></div><div style="text-align: left; font-family: inherit;"><font color="#333333"><br></font></div><div style="text-align: left; font-family: inherit;"><font color="#333333">The solution seemed obvious - why not have a catalogue of experienced tutors who have been publicly rated and reviewed by their students? This way the best tutors would be the most visible, and have the greatest opportunity to impart their wisdom and experience to their students.&nbsp;</font></div><div style="text-align: left; font-family: inherit;"><font color="#333333"><br></font></div><div style="text-align: left; font-family: inherit;"><font color="#333333">Michael (the banker), designed the proprietary system that matched the best tutors to the students, whilst Stevie (the teacher) made it all fit together, incorporating a robust on-boarding process, simple user interface, and regulatory compliance. This was a win-win situation for both the student and tutor, and so Insta-tute was born!</font></div></div> <a data-display-type="block" class="u_1830480089 dmButtonLink dmWidget dmWwr default dmOnlyButton dmDefaultGradient" file="false" href="http://laura3.editor.multiscreensite.com/site/5b24469b/home?preview=true&amp;insitepreview=true&amp;dm_device=desktop#ContactUs" id="1830480089" dm_dont_rewrite_url="false" data-buttonstyle="THICK_BORDER_ROUND" raw_url="/site/5b24469b/home#ContactUs"> <span class="iconBg u_1253421156" id="1253421156"> <span class="icon hasFontIcon icon-star u_1367017171" id="1367017171"></span> 
</span> 
 <span class="text u_1364466910" id="1364466910">GET STARTED TODAY!</span> 
</a> 
</div> 
</div> 
</div> 
 <div class="dmRespRow u_OurExpertise" style="text-align: center;" id="OurExpertise" data-anchor="Our Expertise"> <div class="dmRespColsWrapper" id="1212164135"> <div class="u_1521680417 dmRespCol small-12 medium-12 large-12" id="1521680417"> <h2 class="u_1339038826 dmNewParagraph" id="1339038826" data-uialign="free" style="display: block;"><div style=";text-align: center;"><span style=";color: rgb(255, 255, 255);"></span></div><div style=";text-align: left;"><span style=";color: rgb(255, 255, 255);"></span></div><span class="size-30 lh-1"><div style="text-align: center;">How do we find the perfect tutor?</div></span><div style=";text-align: left;"><span style=";color: rgb(255, 255, 255);"></span></div></h2> <div class="u_1179477731 dmDividerWrapper clearfix" id="1179477731" layout="divider-style-1"><hr class="dmDivider" style="min-height: 2px; border:none; background:grey" id="1635328968"></div> 
 <div class="u_1644176252 dmNewParagraph" data-dmtmpl="true" id="1644176252" data-editor-state="closed" data-uialign="center" style="display: block;"><div style="text-align: center; font-family: inherit;"><span style="color: rgb(51, 51, 51);">We have developed an algorithm much more clever than we are, that takes into consideration many different factors to match the perfect tutor, to the relevant learner in need.</span></div></div> <div class="u_1784985905 dmPhotoGallery dmPhotoGalleryResp" galleryoptionsparams="{&#39;thumbnailsPerRow&#39;:3,&#39;rowsToShow&#39;:&#39;100&#39;,&#39;imageScaleMethod&#39;:true}" data-desktop-text-layout="bottom" data-dmtmpl="true" id="1784985905" data-image-hover-effect="true" data-link-gallery="false" data-pswp-uid="1" data-text-layout="bottom"> <ul class="dmPhotoGalleryHolder clearfix gallery shadowEffectToChildren gallery4inArow ready" id="1199290462" dont_set_id="true" data-d1-gallery-type="square" data-d1-gallery-cols="3" data-d1-mobile-gallery-cols="1"><li class="galleryContainer clearfix"><ul class="galleryColumn clearfix" style="width: 33.3333%; max-width: 320px;"><li index="0" class="photoGalleryThumbs" id="1090216848" data-naturalwidth="700" data-naturalheight="467" data-ratio="0.6671428571428571" style="animation-delay: 0ms; width: 100%; float: left; clear: none; height: auto; max-height: initial; display: block; background: none;"> <div class="image-container" id="1959581723"> <a data-dm-multisize-attr="href" href="./math-700x467.jpg" id="1649572524" class="u_1649572524" data-image-url="https://irp-cdn.multiscreensite.com/5b24469b/dms3rep/multi/desktop/math-700x467.jpg" raw_url="https://dp-cdn.multiscreensite.com/d_gallery/firstImages/a_City_skyline_1600_754_d.jpg" style="background-image: url(&quot;https://irp-cdn.multiscreensite.com/5b24469b/dms3rep/multi/desktop/math-700x467.jpg&quot;); height: 320px; opacity: 1;"><img src="./math-700x467.jpg" irh="1" irw="2" id="1645477568" class="" onerror="handleImageLoadError(this)"></a> 
</div> 
 <div class="caption-container u_1319826817" id="1319826817"> <span class="caption-inner" id="1277912017" style="min-height: 68px;"> <h3 class="caption-title u_1951818666" id="1951818666">Skills &amp; Expertise</h3> 
 <p class="caption-text u_1074323971" id="1074323971">The perfect range of skills and expertise for you.</p> 
</span> 
</div> 
</li></ul><ul class="galleryColumn clearfix" style="width: 33.3333%; max-width: 320px;"><li index="1" class="photoGalleryThumbs" id="1070450213" data-naturalwidth="1200" data-naturalheight="801" data-ratio="0.6675" style="animation-delay: 100ms; width: 100%; float: left; clear: none; height: auto; max-height: initial; display: block; background: none;"> <div class="image-container" id="1269268609"> <a data-dm-multisize-attr="href" href="./Walk-Street_1200_801_d.jpg" id="1566819320" class="u_1566819320" data-image-url="https://dp-cdn.multiscreensite.com/e_gallery/Walk-Street_1200_801_d.jpg" raw_url="https://dp-cdn.multiscreensite.com/d_gallery/firstImages/a_Birthday_candles_sparklers_1600_1067_d.jpg" style="background-image: url(&quot;https://dp-cdn.multiscreensite.com/e_gallery/Walk-Street_1200_801_d.jpg&quot;); height: 320px; opacity: 1;"><img src="./Walk-Street_1200_801_d.jpg" irh="2" irw="3" id="1703987889" class="" onerror="handleImageLoadError(this)"></a> 
</div> 
 <div class="caption-container u_1961839373" id="1961839373"> <span class="caption-inner" id="1874966253" style="min-height: 68px;"> <h3 class="caption-title u_1655525525" id="1655525525">Location</h3> 
 <p class="caption-text u_1511235542" id="1511235542">The right distance from your home or school.</p> 
</span> 
</div> 
</li></ul><ul class="galleryColumn clearfix" style="width: 33.3333%; max-width: 320px;"><li index="2" class="photoGalleryThumbs" id="1866728085" data-naturalwidth="1043" data-naturalheight="696" data-ratio="0.6673058485139022" style="animation-delay: 200ms; width: 100%; float: left; clear: none; height: auto; max-height: initial; display: block; background: none;"> <div class="image-container" id="1990813235"> <a data-dm-multisize-attr="href" href="./Girl-smiling-reading-book_1043_696_d.jpg" id="1682636268" class="u_1682636268" data-image-url="https://dp-cdn.multiscreensite.com/e_gallery/Girl-smiling-reading-book_1043_696_d.jpg" raw_url="https://dp-cdn.multiscreensite.com/d_gallery/firstImages/a_fashion_magazine_tablet_1600_1067_d.jpg" style="background-image: url(&quot;https://dp-cdn.multiscreensite.com/e_gallery/Girl-smiling-reading-book_1043_696_d.jpg&quot;); height: 320px; opacity: 1;"><img src="./Girl-smiling-reading-book_1043_696_d.jpg" irh="3" irw="4" id="1586082496" class="" onerror="handleImageLoadError(this)"></a> 
</div> 
 <div class="caption-container" id="1607305242"> <span class="caption-inner" id="1847882808" style="min-height: 68px;"> <h3 class="caption-title" id="1975720229">The Rating</h3> 
 <p class="caption-text" id="1732487119">For every session a tutor conducts, they get a rating.</p> 
</span> 
</div> 
</li></ul></li></ul> 
 <div class="photoGalleryViewAll" isall="true" data-viewall="view all" data-viewless="view less" style="display:none;" id="1659846850">view all <span class="dm-icon-button-arrow oneIcon" id="1788662022"></span> 
</div> 
</div> 
</div> 
</div> 
</div> 
 <div class="u_Testimonials dmRespRow" style="text-align: center;" id="Testimonials" data-anchor="Testimonials"> <div class="dmRespColsWrapper" id="1496573760"> <div class="dmRespCol small-12 medium-12 large-12" id="1884944619"> <span id="1648758314"></span> 
 <h2 class="dmNewParagraph" id="1758522625" style="transition: opacity 1s ease-in-out;"><div style="text-align: center;"><span style="font-weight: 700;">Testimonials</span></div></h2> <div class="u_1394761105 dmDividerWrapper clearfix" id="1394761105" layout="divider-style-1"><hr class="dmDivider" style="min-height: 2px; border:none; background:grey" id="1391024438"></div> 
</div> 
</div> 
</div> 
 <div class="u_1801184050 dmRespRow fullBleedChanged dmSectionParallaxNew" style="text-align: center;" id="1801184050"> 
     <div class="dmRespColsWrapper u_1558023730" id="1558023730"> 
         <div class="u_1500162096 dmRespCol small-12 medium-4 large-4 wow fadeInUp" id="1500162096" data-anim-desktop="fadeInUp" style="visibility: hidden; animation-name: none;"> 
             <span id="1232006104" class="u_1232006104"></span> 
 <div class="u_1926263726 imageWidget" editablewidget="true" data-widget-type="image" id="1926263726"><img src="./student_3.jpg" id="1656273077" class="u_1656273077" dm_changed="true" onerror="handleImageLoadError(this)"></div> 
 <div class="u_1906545860 graphicWidget" editablewidget="true" data-widget-type="graphic" id="1906545860"> <svg version="1.1" id="1022302793" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 70 70" style="enable-background:new 0 0 70 70;" xml:space="preserve" class="svg u_1022302793" data-icon-custom="true" data-icon-name="QUOTE-01.svg"> <path d="M45.4,49.5c3.5,0,6.5-2.9,6.5-6.6c0-3.7-2.9-6.6-6.5-6.6c-6.5,0-2.2-12.8,6.5-12.8v-3.1C36.5,20.5,30.5,49.5,45.4,49.5
	L45.4,49.5z M26.8,49.5c3.5,0,6.5-2.9,6.5-6.6c0-3.7-2.9-6.6-6.5-6.6c-6.5,0-2.2-12.8,6.5-12.8v-3.1C17.9,20.5,11.9,49.5,26.8,49.5
	L26.8,49.5z" id="1437687999"></path> 
</svg> 
</div> 
 <div class="u_1601731570 dmNewParagraph" data-dmtmpl="true" id="1601731570" data-editor-state="closed" data-uialign="center" style="display: block;"><div style="text-align: center;"><span style="color: rgb(51, 51, 51);">"My daughter was really struggling with her reading and the tutor we got paired with was such a lovely, understanding, empathetic support for her.&nbsp;</span></div></div> <h4 class="u_1228286436 dmNewParagraph" id="1228286436" style="display: block;" data-uialign="center"><div style="text-align: center; font-family: inherit;"><span style="font-family: inherit;"><font style="font-family: inherit;"><b></b></font></span></div><div style="font-weight: 700; text-align: center; font-family: inherit;"><span style="font-family: inherit; font-weight: inherit;"><font style="font-family: inherit;"><b>Caralynn W.</b></font></span></div><div style="text-align: center; font-family: inherit;"><i>Parent</i></div></h4></div> 
 <div class="u_1593917333 dmRespCol small-12 medium-4 large-4 wow fadeInUp" id="1593917333" data-anim-desktop="fadeInUp" style="visibility: hidden; animation-name: none;"> <span id="1200037867" class="u_1200037867"></span> 
 <div class="u_1355949898 imageWidget" editablewidget="true" data-widget-type="image" id="1355949898"><img src="./student_2.jpg" id="1996316895" class="u_1996316895" dm_changed="true" onerror="handleImageLoadError(this)"></div> 
 <div class="u_1763253063 graphicWidget" editablewidget="true" data-widget-type="graphic" id="1763253063"> <svg version="1.1" id="1968735791" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 70 70" style="enable-background:new 0 0 70 70;" xml:space="preserve" class="svg u_1968735791" data-icon-custom="true" data-icon-name="QUOTE-01.svg"> <path d="M45.4,49.5c3.5,0,6.5-2.9,6.5-6.6c0-3.7-2.9-6.6-6.5-6.6c-6.5,0-2.2-12.8,6.5-12.8v-3.1C36.5,20.5,30.5,49.5,45.4,49.5
	L45.4,49.5z M26.8,49.5c3.5,0,6.5-2.9,6.5-6.6c0-3.7-2.9-6.6-6.5-6.6c-6.5,0-2.2-12.8,6.5-12.8v-3.1C17.9,20.5,11.9,49.5,26.8,49.5
	L26.8,49.5z" id="1989604302"></path> 
</svg> 
</div> 
 <div class="u_1103702468 dmNewParagraph" data-dmtmpl="true" id="1103702468" data-editor-state="closed" data-uialign="center" style="display: block;"><div style="text-align: center;">“You really helped me through Basic Science, and this enabled me to get into the course that I really wanted! I can't thank you enough."</div><div style="text-align: center;"><br></div><div style="text-align: center;"><font color="#333333"><span style="line-height: normal; font-weight: 300;"></span></font></div></div> <h4 class="u_1813040098 dmNewParagraph" id="1813040098" style="display: block;" data-uialign="center"><div style="text-align: center; font-family: inherit;"><span style="font-family: inherit;"><b></b></span></div><span style="font-weight: 700;"><div style="text-align: center; font-family: inherit;"><span style="font-family: inherit; font-weight: inherit;"><b>Brian R.</b></span></div><div style="text-align: center; font-family: inherit;"></div></span><div style="text-align: center; font-family: inherit;"><span style="font-family: inherit;"><i>Science Student</i></span></div></h4></div> 
 <div class="u_1048161822 dmRespCol small-12 medium-4 large-4 wow fadeInUp" id="1048161822" data-anim-desktop="fadeInUp" style="visibility: hidden; animation-name: none;"> <span id="1517060937" class="u_1517060937"></span> 
 <div class="u_1049291576 imageWidget" editablewidget="true" data-widget-type="image" id="1049291576"><img src="./student_1.jpg" id="1451842801" class="u_1451842801" dm_changed="true" onerror="handleImageLoadError(this)"></div> 
 <div class="u_1575311475 graphicWidget" editablewidget="true" data-widget-type="graphic" id="1575311475"> <svg version="1.1" id="1557682965" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 70 70" style="enable-background:new 0 0 70 70;" xml:space="preserve" class="svg u_1557682965" data-icon-custom="true" data-icon-name="QUOTE-01.svg"> <path d="M45.4,49.5c3.5,0,6.5-2.9,6.5-6.6c0-3.7-2.9-6.6-6.5-6.6c-6.5,0-2.2-12.8,6.5-12.8v-3.1C36.5,20.5,30.5,49.5,45.4,49.5
	L45.4,49.5z M26.8,49.5c3.5,0,6.5-2.9,6.5-6.6c0-3.7-2.9-6.6-6.5-6.6c-6.5,0-2.2-12.8,6.5-12.8v-3.1C17.9,20.5,11.9,49.5,26.8,49.5
	L26.8,49.5z" id="1431349176"></path> 
</svg> 
</div> 
 <div class="u_1250169002 dmNewParagraph" data-dmtmpl="true" id="1250169002" data-editor-state="closed" data-uialign="center" style="display: block;"><div style="text-align: center;">“My tutoring sessions were fun. I had a couple of different tutors for different subjects I was struggling with, and both tutors were a perfect fit for my needs.”</div><div style="text-align: center;"><font color="#333333"><span style="line-height: normal; font-weight: 300;"></span></font></div></div> <h4 class="u_1590445939 dmNewParagraph" id="1590445939" style="display: block;" data-uialign="center"><div style="text-align: center; font-family: inherit;"><font style="font-family: inherit;"><b></b></font></div><span style="font-weight: 700;"><div style="text-align: center; font-family: inherit;"><font style="font-family: inherit;"><b>Rachel L.</b></font></div><div style="text-align: center; font-family: inherit;"></div></span><div style="text-align: center; font-family: inherit;"><font style="font-family: inherit;"><i>Maths Student</i></font></div></h4></div> 
</div> 
</div> 
 <div class="u_SpecialOffer dmRespRow fullBleedChanged dmSectionParallaxNew hasBackgroundOverlay" style="text-align: center;" id="SpecialOffer" data-anchor="Special Offer"> <div class="dmRespColsWrapper u_1148020381" id="1148020381"> <div class="dmRespCol small-12 medium-6 large-6 emptyColumn" id="1929984458"> <div class="u_1251712205 dmSpacer" id="1251712205"></div> 
</div> 
 <div class="u_1991521592 dmRespCol small-12 medium-6 large-6 wow fadeInRight" id="1991521592" data-anim-desktop="fadeInRight" style="visibility: hidden; animation-name: none;"> <span id="1007447256" class="u_1007447256"></span> 
 <h2 class="u_1055860689 dmNewParagraph" id="1055860689" style="transition: opacity 1s ease-in-out;" data-uialign="center"><div style="text-align: center;"><span style=""></span></div><div style="text-align: center;"><span style="font-weight: normal;"></span></div><div style="text-align: center;"><span style=""></span></div><span style="font-weight: 700;" class="m-specific m-size-38 lh-1"><div style="text-align: center;"><span style="font-weight: inherit;">Special Offer:</span></div><div style="text-align: center;">Refer a friend</div></span><div style="text-align: center;"></div><div style="text-align: center;"><span style="font-weight: normal;"></span></div><div style="text-align: center;"></div></h2> <h1 class="u_1902431352 dmNewParagraph" id="1902431352" style="display: block;" data-uialign="center"><div style="text-align: center;"><span style="background-color: transparent;"><font style="font-family: inherit; color: rgb(26, 149, 193);">30% off</font></span></div></h1> <h4 class="dmNewParagraph u_1705472567" id="1705472567" data-uialign="center" style="" data-editor-state="closed"><div style="text-align: center;"><span style="font-weight: normal;">Refer a friend 
or classmate and save 30% on your next session.</span></div></h4></div> 
</div> 
</div> 
 <div class="u_1016632901 dmRespRow fullBleedChanged fullBleedMode" style="text-align: center;" id="1016632901"> <div class="dmRespColsWrapper" id="1309305904"> <div class="dmRespCol small-12 medium-12 large-12 emptyColumn" id="1350209518"> <span id="1382537747"></span> 
</div> 
</div> 
</div> 
</div> 
</div> 
</div> 
</div> 
 <div class="dmFooterContainer"> <div id="fcontainer" class="u_fcontainer f_hcontainer dmFooter p_hfcontainer"> <div dm:templateorder="250" class="dmFooterResp generalFooter" id="1943048428"> <div class="u_1305047213 dmRespRow" style="text-align: center;" id="1305047213"> <div class="dmRespColsWrapper" id="1531499245"> <div class="dmRespCol small-12 medium-12 large-12" id="1672100262"> <span id="1436558846"></span> 
 <div class="u_1827145998 graphicWidget" editablewidget="true" data-widget-type="graphic" id="1827145998"> <a href="#Home" id="1332606105" dm_dont_rewrite_url="false" file="false" raw_url="/site/5b24469b/home#Home"> <svg viewBox="0 0 1152 1792" id="1589143939" class="svg u_1589143939" data-icon-name="fa-angle-up"> <path fill="inherit" d="M1075 1184q0 13-10 23l-50 50q-10 10-23 10t-23-10l-393-393-393 393q-10 10-23 10t-23-10l-50-50q-10-10-10-23t10-23l466-466q10-10 23-10t23 10l466 466q10 10 10 23z" id="1140337485"></path> 
</svg> 
</a> 
</div> 
</div> 
</div> 
</div> 
 <div class="dmRespRow fullBleedChanged fullBleedMode u_1755706785" style="text-align: center;" id="1755706785"> <div class="dmRespColsWrapper" id="1423881976"> <div class="u_1060553766 dmRespCol small-12 large-5 medium-5" id="1060553766"> <h3 class="u_1771987519 dmNewParagraph" id="1771987519" data-uialign="center" style="transition: opacity 1s ease-in-out;"><font style="color: rgb(255, 255, 255);">Insta-tute</font></h3> <h3 class="u_1519684837 dmNewParagraph" id="1519684837" data-uialign="right" style="transition: opacity 1s ease-in-out;"><font style="color: rgb(255, 255, 255);" class="size-15 lh-1">PO Box 209, Gordon, NSW, 2072</font></h3> <div class="u_1158140086 align-center text-align-center dmSocialHub" id="1158140086" dmle_extension="social_hub" wr="true" networks="" icon="true" surround="true" adwords="" data-editor="eyJ0aXRsZSI6IiIsImRpc3BsYXlUaXRsZSI6ZmFsc2UsImZvcmNlRGlzcGxheSI6ZmFsc2UsImxheW91dCI6IiIsIm5ldHdvcmtzIjpbeyJ1cmwiOiJodHRwczovL2ZhY2Vib29rLmNvbS8iLCJvcmRlciI6MTUsImRlZmF1bHROZXR3b3JrIjpmYWxzZSwiaWQiOiJmYWNlYm9vayIsImljb25fY2xhc3MiOiIiLCJpY29uX2N1c3RvbSI6IiJ9LHsidXJsIjoibWFpbHRvOiIsIm9yZGVyIjoxNywiZGVmYXVsdE5ldHdvcmsiOmZhbHNlLCJpZCI6ImVtYWlsIiwiaWNvbl9jbGFzcyI6IiIsImljb25fY3VzdG9tIjoiIn0seyJ1cmwiOiJodHRwOi8vaW5zdGFncmFtLmNvbS8iLCJvcmRlciI6MTgsImRlZmF1bHROZXR3b3JrIjpmYWxzZSwiaWQiOiJpbnN0YWdyYW0iLCJpY29uX2NsYXNzIjoiIiwiaWNvbl9jdXN0b20iOiIifSx7InVybCI6Imh0dHA6Ly9saW5rZWRpbi5jb20vIiwib3JkZXIiOjIwLCJkZWZhdWx0TmV0d29yayI6ZmFsc2UsImlkIjoibGlua2VkaW4iLCJpY29uX2NsYXNzIjoiIiwiaWNvbl9jdXN0b20iOiIifV0sImljb25zX3N0eWxlIjoiMyIsImFsbF9wYWdlcyI6ZmFsc2V9"> <div class="socialHubWrapper"> <div class="socialHubInnerDiv "> <a href="https://facebook.com/" target="_blank" dmle_dont_remove="target" dm_dont_rewrite_url="true"> <span class="dmSocialFacebook dm-icon-facebook oneIcon socialHubIcon style3"></span> 
</a> 
 <a href="mailto:" target="_blank" dmle_dont_remove="target" dm_dont_rewrite_url="true"> <span class="dmSocialEmail dm-social-icon-email oneIcon socialHubIcon style3"></span> 
</a> 
 <a href="http://instagram.com/" target="_blank" dmle_dont_remove="target" dm_dont_rewrite_url="true"> <span class="dmSocialInstagram icon-instagram oneIcon socialHubIcon style3"></span> 
</a> 
 <a href="http://linkedin.com/" target="_blank" dmle_dont_remove="target" dm_dont_rewrite_url="true"> <span class="dmSocialLinkedin icon-linkedin oneIcon socialHubIcon style3"></span> 
</a> 
</div> 
</div> 
</div> 
</div> 
 <div class="u_1444728123 dmRespCol small-12 large-2 medium-2" id="1444728123"> <span id="1834373760"></span> 
 <div class="dmNewParagraph u_1135515644" data-dmtmpl="true" id="1135515644" data-uialign="center" style="transition: opacity 1s ease-in-out;" data-editor-state="closed"><div><span style="font-family: Montserrat; font-weight: 700;" class="size-14 lh-1"><b><font style="color: rgb(255, 255, 255);"><a href="http://laura3.editor.multiscreensite.com/site/5b24469b/newpage?preview=true&amp;insitepreview=true&amp;dm_device=desktop" runtime_url="/newpage" style="color: rgb(255, 255, 255);" raw_url="/site/5b24469b/newpage">Terms &amp; Conditions</a><div><br></div><div><a href="http://laura3.editor.multiscreensite.com/site/5b24469b/privacy-policy?preview=true&amp;insitepreview=true&amp;dm_device=desktop" runtime_url="/privacy-policy" style="color: rgb(255, 255, 255);" raw_url="/site/5b24469b/privacy-policy">Privacy Policy</a></div><div><br></div><div><a href="http://laura3.editor.multiscreensite.com/site/5b24469b/disclaimer1?preview=true&amp;insitepreview=true&amp;dm_device=desktop" runtime_url="/disclaimer1" style="color: rgb(255, 255, 255);" raw_url="/site/5b24469b/disclaimer1">Disclaimer</a></div></font></b></span></div><div></div></div></div> 
 <div class="u_1639113991 dmRespCol small-12 large-5 medium-5" id="1639113991"> <span id="1482600008"></span> 
 <h6 class="dmNewParagraph" id="1710963043" data-uialign="right" style="transition: opacity 1s ease-in-out;"><font style="color: rgb(255, 255, 255); text-decoration-line: underline;" class="size-15 lh-1"><b><span style="font-family: Montserrat;" class="size-14 lh-1">Enter email address &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</span></b></font></h6> <a data-display-type="block" class="u_1091424852 align-center dmButtonLink dmWidget dmWwr default dmOnlyButton dmDefaultGradient" file="false" href="http://laura3.editor.multiscreensite.com/site/5b24469b/home?preview=true&amp;insitepreview=true&amp;dm_device=desktop" id="1091424852" data-buttonstyle="ANIMATED" raw_url="/site/5b24469b/home"> <span class="iconBg" id="1438623921"> <span class="icon hasFontIcon icon-star" id="1434517955"></span> 
</span> 
 <span class="text" id="1370129764">Subscribe</span> 
</a> 
</div> 
</div> 
</div> 
</div> 
 <div id="1236746004" dmle_extension="powered_by" wr="false" icon="true" surround="false" data-dmtmpl="true"></div> 
</div> 
</div> 
</div> 
</div> 
</div> 
</div> 
</div> 
</div> 
</div> 
</div> 
</div></div>

<!--  Add full CSS and Javascript before the close tag of the body if needed -->
<script type="text/javascript">
(function() {
 	var campaign = (/utm_campaign=([^&]*)/).exec(window.location.search);
 	
 	if (campaign && campaign != null && campaign.length > 1) {
 		campaign = campaign[1]; 		
 		document.cookie = "_dm_rt_campaign=" + campaign + ";expires=" + new Date().getTime() + 24*60*60*1000 + ";domain=" + window.location.hostname + ";path=/";
 	}
}());
</script>
<script type="text/javascript">
  var _dm_gaq = {};
  var _gaq = _gaq || [];
  var _dm_insite = [];
  
  </script>

<div style="display:none;" id="P6iryBW0Wu"></div>

<!-- photoswipe markup -->







<!-- Root element of PhotoSwipe. Must have class pswp. -->
<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">

    <!-- Background of PhotoSwipe. 
         It's a separate element as animating opacity is faster than rgba(). -->
    <div class="pswp__bg"></div>

    <!-- Slides wrapper with overflow:hidden. -->
    <div class="pswp__scroll-wrap">

        <!-- Container that holds slides. 
            PhotoSwipe keeps only 3 of them in the DOM to save memory.
            Don't modify these 3 pswp__item elements, data is added later on. -->
        <div class="pswp__container">
            <div class="pswp__item"></div>
            <div class="pswp__item"></div>
            <div class="pswp__item"></div>
        </div>

        <!-- Default (PhotoSwipeUI_Default) interface on top of sliding area. Can be changed. -->
        <div class="pswp__ui pswp__ui--hidden">

            <div class="pswp__top-bar">

                <!--  Controls are self-explanatory. Order can be changed. -->

                <div class="pswp__counter"></div>

                <button class="pswp__button pswp__button--close" title="Close (Esc)"></button>

                <button class="pswp__button pswp__button--share" title="Share"></button>

                <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button>

                <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>

                <!-- Preloader demo http://codepen.io/dimsemenov/pen/yyBWoR -->
                <!-- element will get class pswp__preloader--active when preloader is running -->
                <div class="pswp__preloader">
                    <div class="pswp__preloader__icn">
                      <div class="pswp__preloader__cut">
                        <div class="pswp__preloader__donut"></div>
                      </div>
                    </div>
                </div>
            </div>

            <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
                <div class="pswp__share-tooltip"></div> 
            </div>

            <button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)">
            </button>

            <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)">
            </button>

            <div class="pswp__caption">
                <div class="pswp__caption__center"></div>
            </div>

        </div>

    </div>

</div>

<!--<script>
var dmForceShare = false;
dmForceShare = true;if (dmForceShare || $("#shareSection").length > 0 || $(".dmShare").length > 0 ){dmLoadShare();}
function dmLoadShare(){
/* google plus shares */
$.ajax({url: "https://apis.google.com/js/plusone.js",dataType: "script",success: function () {}});
/* linked in shares */
$.ajax({url: "https://platform.linkedin.com/in.js",dataType: "script",success: function () {}});
/* Twitter Shares */
$.ajax({url: "https://platform.twitter.com/widgets.js",dataType: "script",success: function () {}});
}
</script>-->

<!--<div id="fb-root" data-locale="en_US" class=" fb_reset"><div style="position: absolute; top: -10000px; height: 0px; width: 0px;"><div></div></div><div style="position: absolute; top: -10000px; height: 0px; width: 0px;"><div><iframe name="fb_xdm_frame_http" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" id="fb_xdm_frame_http" aria-hidden="true" title="Facebook Cross Domain Communication Frame" tabindex="-1" src="./iKWhU6BAGf7.html" style="border: none;"></iframe><iframe name="fb_xdm_frame_https" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" id="fb_xdm_frame_https" aria-hidden="true" title="Facebook Cross Domain Communication Frame" tabindex="-1" src="./iKWhU6BAGf7(1).html" style="border: none;"></iframe></div></div></div>-->

<!--  site ID: 4731451 -->
<!--  Alias: 5b24469b -->
<!--  device: DESKTOP -->
<!--  page ID: 24531851 -->
<!--  generated: Thu Jan 01 00:00:00 UTC 1970 -->
<!--  Server: direct-edit-as-099dee0b3cc5bcbd1 -->

<!--<script>
// Collects client data and updates cookies used by smart sites
var expireDays = 365,visitLength = 30 * 60000;
$.setCookie("dm_timezone_offset", (new Date()).getTimezoneOffset(), expireDays);
function setSmartSiteCookies() {
	setSmartSiteCookiesInternal("dm_this_page_view","dm_last_page_view","dm_total_visits","dm_last_visit");
}
$.DM.events.on("afterAjax", setSmartSiteCookies);
setSmartSiteCookies();
</script>-->

<script type="text/javascript">
$.extend(Parameters,{
 AjaxContainer : "div.dmBody",
 WrappingContainer : "div.dmOuter",
 HomeUrl : "http://laura3.editor.multiscreensite.com/site/5b24469b",
 SiteAlias : "5b24469b",
 SiteId : "4731451",
 SiteType : eval(Base64.decode("J0RVREFPTkUn")),
 ExternalUid: null,
 IsSEOFriendlyLinks : true,
 IsSiteMultilingual: false,
 InitialPageAlias : "home",
 InitialEncodedPageAlias : "aG9tZQ",
 IsFromScratch : "false",
 CurrentPageUrl : "null",
 IsCurrentHomePage : true,
 classicLink : "",
 AllowAjax : true,
 AfterAjaxCommand : null,
 HomeLinkText:"Back To Home",
 UseGalleryModule : false,
 CurrentThemeName : "Layout Theme",
 ThemeVersion : "165",
 DefaultPageAlias : "",
 RemoveDID : true,
 LayoutVariationID : {desktop : 5}, 
 LayoutID : {desktop : 6},
 WidgetStyleID : null,
 IsHeaderFixed: false,
 IsHeaderSkinny: false,
 IsBfs: true,
 LayoutParams : {_manifestId : 10600,_device : "desktop"},
 StorePageAlias: "null",
 StorePath: "",
 StoreCleanUrl:true,
 NotificationSubDomain: "null",
 HasCustomDomain: false,
showCookieNotification: false,
cookiesNotificationMarkup: 'null',
translatedPageUrl: '',
isFastMigrationSite: false

});
$.extend(Parameters.NavigationAreaParams,{
 ShowBackToHomeOnInnerPages : true,
 NavbarSize : -1,
 NavbarLiveHomePage : "http://laura3.editor.multiscreensite.com/site/5b24469b",
 BlockContainerSelector : ".dmBody",
 NavbarSelector : "#dmNav:has(a)",
 SubNavbarSelector : "#subnav_main"
});
$.extend(Parameters.LayoutParams, {_navigationAnimationStyle : 'slide'});

Parameters.NavigationAreaParams.MoreButtonText = 'MORE';

Parameters.NavigationAreaParams.LessButtonText = 'LESS';
Parameters.HomeLinkText = 'Home';
</script>

<script>

jQuery(window).load(function () {
	try {
		var w = window.parent.document,
		        isPreviewEditor = w && w.getElementById('PreviewPaneWrapper') && w.getElementById('PreviewPaneWrapper').getAttribute('device') === "all",
		        isPreviewNoEditor = w && w.body.className.indexOf('onePreviewBody') > -1,
		        isPreviewMultiScreen = isPreviewEditor || isPreviewNoEditor;
		//if(isPreviewMultiScreen) {$.layoutManager.initLayout();}
		jQuery.DM.updateIOSHeight();
	} catch(e){}; 
});
</script>

<script>
	$(document.body).on("click", "a[href^='tel:'] , a[href^='sms:']", function(event){
		if ($.DM && $.DM.isTouchDevice){
			return true;
		} else {
			event.preventDefault();	
		}
		
	});
	</script>
<!--  End Script tags -->


<!--<iframe id="rufous-sandbox" scrolling="no" frameborder="0" allowtransparency="true" allowfullscreen="true" style="position: absolute; visibility: hidden; display: none; width: 0px; height: 0px; padding: 0px; border: none;" title="Twitter analytics iframe" src="./saved_resource(2).html"></iframe>-->

<div class="dmPopupMask" id="dmPopupMask" style="display: none;"></div><div id="dmPopup" class="dmPopup" style="display: none;">
	<div class="dmPopupCloseWrapper"> <div class="dmPopupClose dm-icon-x_close_popup oneIcon" onclick="dmHidePopup(event);"></div> </div> 
 	<div class="dmPopupTitle"> <span></span> Share by:</div> 
	<div class="data"></div>
</div></body></html>