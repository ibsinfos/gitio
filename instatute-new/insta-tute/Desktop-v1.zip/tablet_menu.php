<!-- tablet menu by gaurav -->
<div id="slideRightNav" class="d-header-wrapper gaurav-mobile-menu"> <div id="toggleMenuTrigger" class="uiBtn toggleMenuTrigger dmNavTriggerButton"> <div class="btnStripe"></div> 
 <div class="btnStripe"></div> 
 <div class="btnStripe"></div> 
</div> 
 <div class="dmHeader p_hfcontainer u_hcontainer fixedHeader fixedHeaderLimitSize dmOnlySkinny"> <div class="logoTitleWrapper"> <div class="u_logo-div logo-div dm_header" id="logo-div" style="display:none;"> <a id="dm-logo-anchor" class="u_dm-logo-anchor dm-logo-anchor" href="#" raw_url=""><img id="dm-logo-image" class="u_dm-logo-image dm-logo-image" src="42b29b43-abdb-46bb-9ddc-8b35013f6004-large-944x250.png" device-src-mobile="" device-src-tablet="" device-src-orig="" onerror=""></a> 
</div> 
 <div class="u_dm-title dm-title dm_header" id="dm-title" device-text-mobile="Tutoring" device-text-tablet="Tutoring" device-text-orig="
   MYLOGO
  ">Tutoring</div> 
</div> 
</div> 
</div>
<!-- #tablet menu by gaurav -->